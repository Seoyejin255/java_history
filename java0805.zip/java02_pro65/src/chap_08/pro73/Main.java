package chap_08.pro73;

public class Main {

	public static void main(String[] args) {
		X x =new X();
		x.Speak_A();
		x.Speak_B();
		System.out.println(x.VALUE1);
				
	}


}
