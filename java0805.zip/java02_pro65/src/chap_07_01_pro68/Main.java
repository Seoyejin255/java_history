package chap_07_01_pro68;

public class Main {

	public static void main(String[] args) {
		A c = new C();//A가 추상클래스인데 왜 객체가 생기는거지???? -> 추상클래스이고뭐고 상관없음
		System.out.println(c.field1);
		//System.out.println(c.field2); <-이건 오류남
	}

}
