package chap_07_01_pro67;

public class D extends B{

	@Override
	void sound() {
		System.out.println("고양이소리");
	}
}
