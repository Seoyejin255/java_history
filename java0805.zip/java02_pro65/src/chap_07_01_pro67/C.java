package chap_07_01_pro67;

public class C extends A{

	@Override
	void sound() {
		System.out.println("캐릭터 소리");
	}
}
