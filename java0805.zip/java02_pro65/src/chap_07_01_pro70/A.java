package chap_07_01_pro70;

public abstract class A {
	public abstract void sound();
}
