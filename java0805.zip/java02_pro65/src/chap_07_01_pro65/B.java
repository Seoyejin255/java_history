package chap_07_01_pro65;

public class B extends A{

}
