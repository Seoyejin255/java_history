package chap_11.ex513;

import java.util.HashMap;

public class HashMapExample {

	public static void main(String[] args) {
		HashMap<String, String> h = new HashMap<>();
		h.put("1", "고양이");//arrayList와는 다르게 앞에 id 값을 넣어서 앞에 맞춰서 꺼낼수 있는 거임.
		h.put("2", "개");
		h.put("3", "말");
		h.put("Animal04", "스컹크");
		String cat = h.get("1");
		System.out.println(cat);
		String dog = h.get("2");
		System.out.println(dog);
		String skunk = h.get("Animal04");
		System.out.println(skunk);
	}
}
