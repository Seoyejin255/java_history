package chap_11;

public class Member2 implements Cloneable{
	public String id;
	public String name;
	public String password;
	public int age;
	public boolean adult;

	public Member2(String id, String name, String password, int age, boolean adult) {
		this.id = id;
		this.name = name;
		this.password = password;
		this.age = age;
		this.adult = adult;
	}
	
	public Member2 getMember() {//getMember 메소드
		Member2 cloned = null; 
		try {
			cloned =(Member2)clone();//Member2의 필드값과 동일한 값을 가지는 새로운 객체 생성.
		}catch(CloneNotSupportedException e) {}
		return cloned;
	}
}
