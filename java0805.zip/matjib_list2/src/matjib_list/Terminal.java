package matjib_list;

import java.util.ArrayList;
import java.util.List;

import matjib_list.board.Board;
import matjib_list.command.Command;
import matjib_list.food.Goyang_Food;
import matjib_list.loginpro.Customer;
import matjib_list.loginpro.Manager;
import matjib_list.parentclass.Area;

public class Terminal {

	public void terminal(ArrayList<String> info) {
		List<String> list = info;
		Area area_go = new Goyang_Food("고양시");
		Manager manager = new Manager();
		manager.input_mem();
		Customer customer = new Board();
		customer.inputMem();
		
		((Goyang_Food)area_go).get_goyang();
		loop:
		while(true) {
			String select=Command.getCommand("기능을 선택해주세요. [맛집/추천/게시판/exit]");
			switch(select) {
			case "맛집":
				String goType=Command.getCommand("어떤 종류를 선택하시겠습니까?[한식/카페/양식]");
				if(goType.equals("한식")||goType.equals("카페")||goType.equals("양식")) {
					((Goyang_Food)area_go).info(goType);
					System.out.println();	
				}else {
					System.out.println("다시 입력해주세요.");
				}
				break;
			case "파주시":
				//단순 반복이니까 패스
				break;
				
			case "추천" :
					((Goyang_Food)area_go).foodRandom();
				break;
				
			case "게시판":
				boolean bflag=true;
				while(bflag) {
					String Bselect=Command.getCommand("기능을 선택하세요.[리스트/글보기/글쓰기/exit]");
					if(Bselect.equals("리스트")) {
						((Board)customer).showList();
					}else if(Bselect.equals("글보기")){
						System.out.println("아직 구현 ㄴㄴ");
					}else if(Bselect.equals("글쓰기")) {
						((Board)customer).create(list.get(0),list);
					}else if(Bselect.equals("exit")) {
						bflag=false;
					}
				}
				break;
			case "exit":
				break loop;
			
			}
		}
	}
}
