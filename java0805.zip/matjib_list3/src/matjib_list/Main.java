package matjib_list;

import java.util.ArrayList;
import java.util.List;

import matjib_list.command.Command;
import matjib_list.loginpro.Customer;
import matjib_list.loginpro.Manager;

public class Main {
	//글쓰기 수정,
	public static void main(String[] args) {
		Customer cus = new Customer();
		cus.inputMem();
		Manager manager = new Manager();
		manager.input_mem();
		Terminal terminal = new Terminal();
		boolean flag = true;
		
		while(flag) {
			ArrayList<String> info = new ArrayList<>();//0:권한, 1:id, 2:nickname << 이건 회원의 정보를 담는 arrayList.
			String power = Command.getCommand("권한 설정 (1)회원 (2)비회원 (3) 관리자");
			String play="true";//권한설정을 해달라는 문자열 ->1,2,3을 벗어나면 다시 입력해달라고 함..
			if(power.equals("1")) {//
				info.add(power);
				info=cus.CusLogin(info);
			}else if(power.equals("2")) {//비회원 -게시판 - 글쓰기 로그인 하는 과정 수정
				info.add("2");
			}else if(power.equals("3")) {//이거 아마 다시 수정해야할듯.
				info.add(power);
				info=(ArrayList<String>) manager.loginPro(info);//수정이 안되는걸 고쳐야함.
			}else {
				System.out.println("다시입력 ㄱㄱ");
				play="false";
			}
			if(play.equals("true")) {
				terminal.terminal(info);
			}
			else if(play.equals("false")){
				System.out.println("권한을 설정해주세요.");
			}
		}
		
	}
}
