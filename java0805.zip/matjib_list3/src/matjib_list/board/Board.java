package matjib_list.board;

import java.util.ArrayList;
import java.util.List;

import matjib_list.command.Command;
import matjib_list.loginpro.Customer;

public class Board extends Customer{

	public String content;
	public String title;
	List<Write> writings = new ArrayList<>();//이게 게시글을 저장하는 리스트
	
	public void create(String power, List<String> list) {//1:id, 2:nickname
				if(power.equals("1")||power.equals("3")) {
					String title=Command.getCommand("<<제목 입력>>");
					String content = Command.getCommand("<<내용 입력>>");
					writings.add(new Write(list.get(2),list.get(1),title,content));
					//닉네임,id,title,content
				}else if(power.equals("2")){
					System.out.println("비회원을 글을 쓸 수 없습니다. 로그인 하시겠습니까?");
					//여기에 다 나가고 로그인 하는 코드 쓰기.
				}
	}
	
//	public void showBoard() {
//		Command.drawLine();
//		System.out.println(title + "\t\t|" + +"|");
//		Command.drawLine();
//		System.out.println(content);
//	} 미완성
	
	public void showList() {
		Command.drawTwoLine();
		Command.drawTwoLine();
		if(writings.size()<0) {
			System.out.println("글이 없습니다.");
		}else {
			for(int i=0;i<writings.size();i++) {
				String str = String.format("[%s]%s | %s ",writings.get(i).id,writings.get(i).nickname,writings.get(i).title);
				System.out.println(str);
				Command.drawLine();
			
			}	
		}
		
		Command.drawTwoLine();
	}
	public List<Write> getList() {
		return writings;
	}
	

}

