package matjib_list;

import java.util.ArrayList;
import java.util.List;

import matjib_list.board.Board;
import matjib_list.board.Write;
import matjib_list.command.Command;
import matjib_list.food.Goyang_Food;
import matjib_list.loginpro.Customer;
import matjib_list.loginpro.Manager;
import matjib_list.parentclass.Area;

public class Terminal {
	List<Write> writings;
	Customer customer = new Board();
	Goyang_Food area_go = new Goyang_Food();
	
	public void terminal(ArrayList<String> info) {
		List<String> list = info;
		area_go.get_goyang();
		
		
		loop:
		while(true) {
			String select = null;
			if(info.get(0).equals("1")||info.get(0).equals("2")) {
				select=Command.getCommand("기능을 선택해주세요. [맛집/추천/게시판/exit]");
			}else if(info.get(0).equals("3")) {
				select = Command.getCommand("기능을 선택해주세요. [맛집/추천/매니저/게시판/exit]")	;
			}
			switch(select) {
			case "맛집":
				String goType=Command.getCommand("어떤 종류를 선택하시겠습니까?[한식/카페/양식]");
				if(goType.equals("한식")||goType.equals("카페")||goType.equals("양식")) {
					area_go.info(goType);
					System.out.println();	
				}else {
					System.out.println("다시 입력해주세요.");
				}
				break;
			case "추천" :
					((Goyang_Food)area_go).foodRandom();
				break;
			case "매니저" :
				boolean flag=true;
				boolean se_flag=true;
				while(flag) {
						while(se_flag) {
							String maSelect=Command.getCommand("[관리자]기능을 선택해주세요. >> (1)리스트수정  (2)리스트추가 (3)exit");
							if(maSelect.equals("1")) {
								String fType=Command.getCommand("어떤 종류의 음식점을 수정하시겠습니까?[한식/카페/양식]");
								if(fType.equals("한식")||fType.equals("카페")||fType.equals("양식")) {
									String fName=Command.getCommand("수정할 가게의 이름은?");
									area_go.editFood(fType,fName);
								}else {
									System.out.println("다시 입력해주세요.");
								}
							}else if(maSelect.equals("2")) {
								area_go.foodAdd();
								
							}else if(maSelect.equals("3")) {
								se_flag=false;
								flag=false;
							}
						}
					}
				break;
			case "게시판":
				boolean bflag=true;
				while(bflag) {
					String Bselect=Command.getCommand("기능을 선택하세요.[리스트/글보기/글쓰기/exit]");
					if(Bselect.equals("리스트")) {
						((Board)customer).showList();
					}else if(Bselect.equals("글보기")){
						System.out.println("아직 구현 ㄴㄴ");
					}else if(Bselect.equals("글쓰기")) {
						((Board)customer).create(list.get(0),list);
					}else if(Bselect.equals("exit")) {
						bflag=false;
					}
				}
				break;
			case "exit":
				break loop;
			}
		}
	}
}
