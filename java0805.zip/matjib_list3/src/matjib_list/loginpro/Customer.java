package matjib_list.loginpro;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import matjib_list.board.Write;
import matjib_list.command.Command;

public class Customer{
	Map<String,User> customer = new HashMap<>();
//	public String nowCus;
//	public String status;
//	public String nowNick;
	public void inputMem() {
		customer.put("mem1", new User("1234","멍청이"));
	}
	

	public ArrayList<String> CusLogin( ArrayList<String> info) {
//		Init();
		boolean flag=true;
		while(flag) {
			String id = Command.getCommand("아이디를 입력해주세요.");
			String pw = Command.getCommand("비밀번호를 입력해주세요.");
			if(customer.get(id)!=null) {
				if((customer.get(id).pw).equals(pw)) {
					String nickname=customer.get(id).nickname;
					System.out.println("--------------------"+nickname+"님 안녕하세요 ^^--------------------");
					info.add(id);
					info.add(nickname);
					flag =false;
				}else if(((customer.get(id).pw).equals(pw))!=true){
					String logFlag=Command.getCommand("비밀번호가 다릅니다. 다시 로그인 하시겠습니까 ? [yes/no]");
					//여기에서 갑자기 terminal로 들어감 ㅠㅠ 수정해야됨..ㅠㅠㅠㅠㅠ
					if(logFlag.equals("yes")) {
					}else if(logFlag.equals("no")) {
						flag=false;
					}
				}
			}else {
				System.out.println("id가 다릅니다. 다시 입력해주세요.");
			}
			}
			return info;
	}
	public void Init() {
//		status=null;
//		nowCus=null;
//		nowNick=null;
	}
	
}
