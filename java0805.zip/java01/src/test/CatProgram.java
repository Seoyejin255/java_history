package test;

import java.util.Scanner;

public class CatProgram {
	
	public static void main(String[] args) {
		String id;
		String pw;
		String flag_s;
		boolean flag=true;
		Scanner sc= new Scanner(System.in);
		
		while(flag) {
			System.out.println("로그인할거면 로그인 입력 ㄱㄱ");
			String log_in =sc.next();
			if(log_in.equals("로그인")) {
				System.out.println("id를 입력해주세요.");
				id =sc.next();
				System.out.println("pw를 입력해주세요.");
				pw =sc.next();
				if(id.equals("고양이")&&pw.equals("고양이")) {
					System.out.println("로그인 성공");
				}else {
					System.out.println("로그인 실패");
				}
			}
			System.out.println("종료하시려면 exit를 입력해주세요.");
			flag_s =sc.next();
			if(flag_s.equals("exit"))flag=false;
		}
		
		}
		

}
