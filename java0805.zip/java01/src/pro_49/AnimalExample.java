package pro_49;

import java.util.ArrayList;

public class AnimalExample {

	public static void main(String[] args) {
		
		ArrayList<Animal> animals = new ArrayList<Animal>();
		
		animals.add(new Cat("야옹이"));
		animals.add(new Snake("뱀뱀이"));
		animals.add(new Halk("헐크"));
		//부모의 배열에 자식 배열을 넣음,자식아닌건 못넣음
		
		for(int i=0;i<animals.size();i++) {
			animals.get(i).sound();
			animals.get(i).move();
		}
	}

}
