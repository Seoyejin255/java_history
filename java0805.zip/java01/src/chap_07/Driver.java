package chap_07;

public class Driver {
	public void drive(Vehicle vehicle) {
		vehicle.run();
	}
}
