package chap_07;

public class InstanceofExample {
	//문제의 본질 : 좌항의 객체가 우항의 타입으로 생성된게 맞는지 확인하고(자식) 맞으면 강제 형변환, 아니면 변환x
	public static void method1(Parent parent) {//Parent parentA<-(new Child())
		if(parent instanceof Child) {//parent객체가 Child타입으로 객체가 생성된게 맞는가(본질이 child인가)
			Child child = (Child)parent;//강제 형변환 성공(부모인척 하고있는 객체를 child객체로 강제 형변환시켜버림.)
			System.out.println("method1 - Child로 변환성공");
		}else {//받지 않았으면
			System.out.println("method1-Child로 변환되지 않음.");
		}	
	}
	
	public static void method2(Parent parent) {
		Child child =(Child) parent;
		System.out.println("method2-Child로 변환성공");
	}
	
	public static void main(String[] args) {
		Parent parentA = new Child();//parentA 객체는 부모인척 하는 자식임.
		method1(parentA);//"method1-Child로 변환성공"
		method2(parentA);//실행됨
		
		Parent parentB =new Parent();//parentB객체는 부모임.
		method1(parentB);//"method1-Child로 변환되지 않음"
		method2(parentB);//실행되지 않음.<-예외 발생.
	}
}
