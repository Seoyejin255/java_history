package chap_06;

public class Monster {
	String name;
	int currentHp;
	int maxHp;
	int atk;
	
	 
	 
	 Monster(String name) {
		this(name,100,100,30);
	}
	 
	 Monster(String name,int currentHp) {
		this(name,currentHp,100,300);
	 }
	
	 Monster(String name,int currentHp,int maxHp) {
		this(name,currentHp,maxHp,400);
	 }
	 
	 Monster(String name,int currentHp,int maxHp,int atk) {
		 this.name = name;
		 this.currentHp = currentHp;
		 this.maxHp = maxHp;
		 this.atk = atk;
	 }
	 
		int Mons_attack(int elf_atk) {
			this.currentHp-= Random_attack(elf_atk);
			return currentHp;
		}
		
		int Random_attack(int elf_atk) {
			int attack=elf_atk;
			double randomValue = Math.random();
			int random = (int)(randomValue * attack)+1;
			return random;
		}
	}

