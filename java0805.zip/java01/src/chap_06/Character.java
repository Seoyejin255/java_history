package chap_06;
import java.util.*;

public class Character {
	static final String CAT="고앵이잉";
	String name;
	int currentHp;
	int maxHp;
	int atk;
	
	Character(String name,int currentHp,int maxHp,int atk) {
		this.name = name;
		this.currentHp = currentHp;
		this.maxHp = maxHp;
		this.atk = atk;
	}
	
	Character(String name,int currentHp,int maxHp) {
		this.name = name;
		this.currentHp = currentHp;
		this.maxHp = maxHp;
	}
	
	Character(String name,int currentHp) {
		this.name = name;
		this.currentHp = currentHp;
	}
	
	Character(String name) {
		this.name = name;
	}
	
	int Charac_attack(int mons_atk) {
		this.currentHp-=Random_attack(mons_atk);
		return currentHp;
	}
	
	int Random_attack(int mons_atk) {
		int attack = mons_atk;
		double randomValue = Math.random();
		int random = (int)(randomValue * attack)+1;
		return random;
	}
}
