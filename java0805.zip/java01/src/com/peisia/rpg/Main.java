package com.peisia.rpg;

import java.util.ArrayList;
import com.peisia.rpg.obj.GameObject;
import com.peisia.rpg.obj.Mob;
import com.peisia.rpg.obj.Npc;
import com.peisia.rpg.obj.Player;


public class Main {
	public static void main(String[] args) {
		ArrayList<GameObject> gameobjs = new ArrayList<>();
		gameobjs.add(new Player("player","플레이어"));
		gameobjs.add(new Npc("npc","엔피씨"));
		gameobjs.add(new Mob("mob","몹"));
		
		for(int i=0;i<gameobjs.size();i++) {
			gameobjs.get(i).info();
		}
	}
}
