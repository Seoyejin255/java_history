package com.peisia;

public class Game {
	public void info() {
		System.out.println("peisia");
	}
}
