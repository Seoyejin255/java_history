package chap_05;

public class ArrayCopyByForExample {
	public static void main(String[] args) {
		//타입[] 변수 or 타입 변수[]
		int oldIntArray[] = {1,2,3};
		int newIntArray[] = new int[5];
		int new2IntArray[] = new int[5];
		
		for(int i=0; i<oldIntArray.length; i++) {
			newIntArray[i]=oldIntArray[i];
		}
		for(int i=0; i<newIntArray.length; i++) {
			System.out.println(newIntArray[i]+",");
		}
		
		System.arraycopy(oldIntArray,0,new2IntArray,0,oldIntArray.length);

		for(int i=0; i<new2IntArray.length;i++) {
			System.out.println(new2IntArray[i]+",");
		}
		
		String ss[]= {"개","고양이","너굴맨","개"};
		
		if(ss[0]==ss[3]) System.out.println("같음");//앞에 있는 "개"랑 같은 번지를 씀
		else System.out.println("다름");
		
		
		String sss[]= {
				new String("개"),
				new String("고양이"),
				new String("너굴맨"),
				new String("개"),
				
		};//string 이라는 클래스를 생성후 "개"라는 문자열을 넣는것이기에 서로 다름.
		
		if(sss[0]==sss[3]) System.out.println("같음");
		else System.out.println("다름");
	}
}
