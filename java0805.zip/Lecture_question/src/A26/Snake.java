package A26;

public class Snake extends Animal{

}
