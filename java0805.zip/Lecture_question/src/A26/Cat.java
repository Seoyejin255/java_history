package A26;

public class Cat extends Animal{
	public String family;
	
	Cat(String f , String moveType){
		super();
		family=f;
	}
	Cat(){
		
	}
}
