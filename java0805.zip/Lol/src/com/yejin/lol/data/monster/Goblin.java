package com.yejin.lol.data.monster;


import com.yejin.lol.data.user.User;
import com.yejin.lol.util.Dice;

public class Goblin {
	public String name;
	public int currentHp;
	int maxHp;
	int atk;
	User user = new User();
	
	public Goblin(String name,int currentHp,int maxHp,int atk) {
		this.name=name;
		this.currentHp=currentHp;
		this.maxHp=maxHp;
		this.atk=atk;
	}
	

	public void goblin_info(){
		String s = String.format("[이름 : %s]\n체력 : %d / %d\n 공격력 : %d ",this.name,this.currentHp,this.maxHp,this.atk);
		System.out.println(s);
	}
	//1~atk 수치만큼 유저에게 데미지를 입히고 입혔다는 메세지 출력(오크와 고블린)
	public void attack() {
		this.atk=Dice.random(this.atk);
		user.currentHp-=this.atk;
		String s = String.format("%s는 %s에게 %d의 데미지를 입혔습니다.",this.name,user.name,this.atk);
		
		System.out.println(s);
	}


}
