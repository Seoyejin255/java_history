package com.yejin.lol.data.monster;


import com.yejin.lol.data.user.User;
import com.yejin.lol.util.Dice;

public class Orc {
	String name;
	int currentHp;
	int maxHp;
	int atk;
	User user = new User();
	
	public Orc(String name,int currentHp,int maxHp,int atk) {
		this.name=name;
		this.currentHp=currentHp;
		this.maxHp=maxHp;
		this.atk=atk;
	}
	
    public void orc_info(){
		String s = String.format("[이름 : %s]\n체력 : %d / %d\n 공격력 : %d ",this.name,this.currentHp,this.maxHp,this.atk);
		System.out.println(s);
	}
    
    public void attack() {
		this.atk=Dice.random(this.atk);
		user.currentHp-=this.atk;
		String s = String.format("%s는 %s에게 %d의 데미지를 입혔습니다.",this.name,user.name,this.atk);
		System.out.println(s);
	}
}
