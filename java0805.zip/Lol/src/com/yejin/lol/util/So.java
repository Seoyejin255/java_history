package com.yejin.lol.util;

public class So {

	public static void pl(String a){
		System.out.println(a);
	}
	public static void p(String a) {
		System.out.print(a);
	}
}
