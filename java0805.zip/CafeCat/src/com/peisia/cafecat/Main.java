package com.peisia.cafecat;

public class Main {
	Kiosk kiosk = new Kiosk();
}
