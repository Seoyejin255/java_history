package com.peisia.cafecat;

public class Kiosk {
	
	public void run() {
//		init();
	}

//	private void init() {//각종 초기화 처리
//		initGoodsData();
//	}
	
}
