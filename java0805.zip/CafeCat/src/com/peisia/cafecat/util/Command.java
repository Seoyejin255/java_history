package com.peisia.cafecat.util;

import java.util.Scanner;

public class Command {
	Scanner sc = new Scanner(System.in);
	
	String getCommand(String guide) {
		System.out.println(guide);
		String cmd = sc.next();
		return cmd;
	}
}
