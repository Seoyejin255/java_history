package chap13_4;
import java.sql.*;

public class tets {
	public static void main(String[] args) {
		String jdbc_driver ="com.mysql.cj.jdbc.Driver";
		String dburl ="jdbc:mysql://localhost:3306/my_board?serverTimezone=UTC";
		String dbUser ="root";		String dbpasswd ="admin";
		try {
			Class.forName(jdbc_driver);
			Connection conn = DriverManager.getConnection(dburl,dbUser,dbpasswd);
			System.out.println("성공");
		}catch(Exception e) {
			System.out.println("연결 안됐음..");
		}
		
	
}
}
