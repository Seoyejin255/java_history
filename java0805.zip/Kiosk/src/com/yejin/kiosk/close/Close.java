package com.yejin.kiosk.close;

public class Close{

	public void close_info(int totalpay, int hyeongeum,int open_money) {//총결제액,현금결제액,금고총액 나오는 함수
		int total=totalpay;
		int hyeon=hyeongeum;
		int openmoney=open_money;
		System.out.println("[TODAY]\n총결제액 : "+total+"\n현금결제 : "+hyeon);
		System.out.println("\n금고 총액 : " + openmoney);
	}
}
