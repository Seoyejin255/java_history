package com.yejin.kiosk.table;

import com.yejin.kiosk.system.Command;
import com.yejin.kiosk.system.Title;

public class Table implements Table_Struct{
	String select_main;
	String food_info;//음식 정보
	public int food_sum;//총 금액
	public int hyeongeum;//현금결제 금액
	//테이블은 get(0) => 기타 정보들 get(1~6)에는 테이블 정보를 적을거임
	
	public Table(int food_sum,int hyeongeum) {
		this.food_sum=food_sum;
		this.hyeongeum=hyeongeum;
	}

	public String Select_main() {//테이블 기능 중 음식, 계산을 고르게함.
		this.select_main=Command.getCommand("기능 선택 : [음식 / 계산]");
		return select_main;
	}
	
	public void Select_food() { 
		this.food_sum+=food_type();
	}
	
	public void Select_pay() {//결제 방식을 선택하고 결제하는 함수
		int pay_sum=this.food_sum;
		String select_pay = Command.getCommand("결제 방식 : [신용카드 / 현금 / 분할결제 ]");
		String devide_pay;
		boolean flag=true;
		while(flag) {
			if(select_pay.equals("신용카드")) {
				flag=false;
			}//신용카드 끝
			else if(select_pay.equals("현금")) {
				this.hyeongeum+=food_sum;
				flag=false;
			}//현금 끝
			else if(select_pay.equals("분할결제")) {
				while(pay_sum!=0) {
					System.out.println("남은 금액 : " + pay_sum);
					devide_pay=Command.getCommand("결제 방식 : [신용카드 / 현금 ]");
					int pay = Integer.parseInt(Command.getCommand("결제 금액"));
					if(devide_pay.equals("신용카드")) {
						pay_sum-=pay;
					}else if(devide_pay.equals("현금")) {
						this.hyeongeum+=pay;
						pay_sum-=pay;
					}
				}
				flag=false;
			}//분할결제 끝
			else {
				System.out.println("다시 입력해주세요.");
				flag=true;
			}
		}
		
	}
	public void order_info(int value, int i) {//테이블 총 결제 정보 나옴.
		int order_value=value;
		int order_i=i;
		String s=String.format("\t\t%d번 테이블 총결제 : %d원",i,value);
		System.out.println(Title.LINE);
		System.out.println(s);
		System.out.println(Title.LINE);
	}
	
}
