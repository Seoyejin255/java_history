package chap13_1;

public class Tv {
	public String a ="어쩔티비";
}
