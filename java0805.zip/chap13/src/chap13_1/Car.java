package chap13_1;

public class Car {
	public String a="부릉이";
}
