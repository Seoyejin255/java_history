package matjib_list.parentclass;

public class Goyang extends Area{

	public Goyang(String name) {
		this.name=name;
	}

}
