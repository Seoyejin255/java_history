package matjib_list.loginpro;

public interface CustomerI {

}
