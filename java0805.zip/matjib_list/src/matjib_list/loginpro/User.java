package matjib_list.loginpro;

import java.util.HashMap;
import java.util.Map;

public class User{
	public String nickname;
	public String pw;

	public User(String pw, String nickname) {
		this.nickname = nickname;
		this.pw = pw;
	}
	
	public void userLogin() {
		
	}
	
}
