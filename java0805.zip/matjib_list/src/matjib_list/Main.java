package matjib_list;

import matjib_list.board.Board;
import matjib_list.command.Command;
import matjib_list.food.Goyang_Food;
import matjib_list.loginpro.Customer;
import matjib_list.loginpro.Manager;
import matjib_list.parentclass.Area;

public class Main {
	/*<<내일 할것들>>-아쉬운것들.
	 * 
	 * 음식점에 별점을 추가하는건 어떨까??
	 */
	public static void main(String[] args) {
		Area area_go = new Goyang_Food("고양시");
		Manager manager = new Manager();
		manager.input_basic();
		Customer customer = new Board();
		customer.inputMem();
		
		((Goyang_Food)area_go).get_goyang();
		loop:
		while(true) {
			String select=Command.getCommand("기능을 선택해주세요. [맛집/추천/관리자/게시판/exit]");
			switch(select) {
			case "맛집":
				String goType=Command.getCommand("어떤 종류를 선택하시겠습니까?[한식/카페/양식]");
				if(goType.equals("한식")||goType.equals("카페")||goType.equals("양식")) {
					((Goyang_Food)area_go).info(goType);
					System.out.println();	
				}else {
					System.out.println("다시 입력해주세요.");
				}
				break;
			case "파주시":
				//단순 반복이니까 패스
				break;
				
			case "추천" :
				String areaType=Command.getCommand("[고양시]를 입력하세요.");
				if(areaType.equals("고양시")) {
					((Goyang_Food)area_go).foodRandom();}	
//				else if(areaType.equals("파주시")){
//					System.out.println("대에충 파주 음식점 ^^");
////					((Goyang_Food)area).foodRandom();	
//				}
				else {
					System.out.println("다시 입력 ㄱㄱ");
				}
				
				break;
				
			case "관리자" :
				boolean flag=true;
				boolean se_flag=true;
				while(flag) {
					String maFlag=manager.loginPro();
					if(maFlag.equals("true")) {
						while(se_flag) {
							String maSelect=Command.getCommand("[관리자]기능을 선택해주세요. >> (1)리스트수정  (2)리스트추가 (3)exit");
							if(maSelect.equals("1")) {
								String fType=Command.getCommand("어떤 종류의 음식점을 수정하시겠습니까?[한식/카페/양식]");
								if(fType.equals("한식")||fType.equals("카페")||fType.equals("양식")) {
									String fName=Command.getCommand("수정할 가게의 이름은?");
									((Goyang_Food)area_go).editFood(fType,fName);
								}else {
									System.out.println("다시 입력해주세요.");
								}
								
							}else if(maSelect.equals("2")) {
								((Goyang_Food)area_go).foodAdd();
								
							}else if(maSelect.equals("3")) {
								se_flag=false;
								flag=false;
							}
						}
						
					}else if(maFlag.equals("false")) {
						String relog=Command.getCommand("로그인을 실패했어요. 다시 로그인하실래요?[yes/no]");
						if(relog.equals("yes")) {
						}else{
							flag=false;
						}
					}
				}
				break;
			case "게시판":
				boolean bflag=true;
				while(bflag) {
					String Bselect=Command.getCommand("기능을 선택하세요.[리스트/글보기/글쓰기/exit]");
					if(Bselect.equals("리스트")) {
						((Board)customer).showList();
					}else if(Bselect.equals("글보기")){
						System.out.println("아직 구현 ㄴㄴ");
					}else if(Bselect.equals("글쓰기")) {
						((Board)customer).create();
						
					}else if(Bselect.equals("exit")) {
						bflag=false;
					}
				}
				break;
			case "exit":
				break loop;
			
			}
		}
	}
}
