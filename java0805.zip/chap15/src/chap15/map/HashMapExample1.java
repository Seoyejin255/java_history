package chap15.map;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class HashMapExample1 {
	public static void main(String[] args) {
		Map<String,Integer> map = new HashMap<>();
		map.put("신", 85);
		map.put("홍", 90);
		map.put("동", 80);
		map.put("김", 95);
		
		System.out.println("총 사이즈 : " + map.size());
		
		Set<String> keySet = map.keySet();
		Iterator<String> keyIterator = keySet.iterator();
		
		while(keyIterator.hasNext()) {
			String name = keyIterator.next();
			int jumsu = map.get(name);
			System.out.println("학생 이름 : " + name + "\t학생점수 : "+jumsu);
		}
		
	}
}
