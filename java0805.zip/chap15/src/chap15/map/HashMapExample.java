package chap15.map;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class HashMapExample {
	public static void main(String[] args) {
		Map<String,Integer> map = new HashMap<>();
		
		map.put("김구라", 30);
		map.put("유재석", 40);
		map.put("강호동", 50);
		map.put("이경규", 60);
		
		System.out.println("김구라 점수 : "+map.get("김구라"));
		
		Set<String> KeySet = map.keySet();
		Iterator<String> ite = KeySet.iterator();
		
		while(ite.hasNext()) {
			String name = ite.next();
			int jumsu = map.get(name);
			System.out.println();
			System.out.println("이름 : "+name + "\t점수 : " +jumsu);
		}
	}
}
