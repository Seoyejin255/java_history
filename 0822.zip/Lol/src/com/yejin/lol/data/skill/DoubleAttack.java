package com.yejin.lol.data.skill;

public class DoubleAttack {

}
