package com.yejin.lol;


import com.yejin.lol.data.control.Game;
import com.yejin.lol.data.img.Entrance;
import com.yejin.lol.data.monster.Goblin;

public class Main {
	public static void main(String[] args) {
		Game game=new Game();
		game.start();
		game.procBattle();
		Entrance.show();
	}
}
