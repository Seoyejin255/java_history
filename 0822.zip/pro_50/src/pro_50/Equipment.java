package pro_50;

public class Equipment extends Item{

}
