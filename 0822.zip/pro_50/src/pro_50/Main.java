package pro_50;

import java.util.ArrayList;

public class Main {
	public static void main(String[] args) {
		ArrayList<GameObject> gameobjs = new ArrayList<>();
		gameobjs.add(new Player("player","플레이어"));
		gameobjs.add(new Npc("npc","엔피씨"));
		gameobjs.add(new Mob("mob","몹"));
		
		for(int i=0;i<gameobjs.size();i++) {
			gameobjs.get(i).info();
		}
	}
}
