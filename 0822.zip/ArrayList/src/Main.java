import java.util.ArrayList;
import java.util.Arrays;

public class Main {

	public static void main(String[] args) {
		ArrayList<String> animals = new ArrayList<>();
			/* 단어 한꺼번에 넣기
			String s[]= {"고양이","개","사자"};
			ArrayList<String> animals2 = new ArrayList<>(Arrays.asList(s));
			for(int i =0;i<animals2.size();i++) {
				System.out.println(animals2.get(i));
			}
			*/
			String cat ="고양이";
			String dog = "개";
			String lion = "사자";

			animals.add(cat);
			animals.add(dog);
			animals.add(lion);
			animals.add("안녕");
			
			for(int i=0;i<4;i++) {
				System.out.println(animals.get(i));
			}
			System.out.println(animals.size());
			for(int i=0;i<2;i++) {
				animals.remove(i);
			}
			System.out.println(animals.size());
			animals.clear();
			System.out.println(animals.size());
	}

}
