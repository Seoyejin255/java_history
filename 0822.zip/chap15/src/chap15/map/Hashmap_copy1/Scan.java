package chap15.map.Hashmap_copy1;

import java.util.Scanner;

public class Scan {

	static String scan(String str) {
		Scanner scn = new Scanner(System.in);
		System.out.println(str);
		String answer=scn.next();
		return answer;
	}
	
}
