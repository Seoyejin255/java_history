package chap15.map.Hashmap_copy1;

public class User {

	public String name;
	private int userAttack=10;

	public User(String name) {
		this.name = name;
	}
	
	
}
