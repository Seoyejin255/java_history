package chap15.map.Hashmap_copy1;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;

public class Main {
	public static void main(String[] args) {
		Map<String,Monster> mons = new HashMap<>();
		
		mons.put("나방",new Monster("나브앙",30));
		mons.put("지렁이", new Monster("지르엉",50));
		mons.put("지네", new Monster("지이네",50));
		
		String select = Scan.scan("[1: 몬스터정보] ");

		//여기에 switch 적기
		Set<String> keySet = mons.keySet();
		Iterator<String> ite = keySet.iterator();
		while(ite.hasNext()) {
			String name = ite.next();
			mons.get(name).info();
		}
	}
}
