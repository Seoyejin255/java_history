package chap15.map.Hashmap_prac;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;

public class Main {

	public static void main(String[] args) {
		HashMap<String,Item> itemData = new HashMap<>();
		itemData.put("sword01", new Item("단검",100));
		itemData.put("sword02", new Item("장검",200));
		itemData.put("ward01", new Item("와드",300));
		
		itemData.remove("ward01");
		Item i = itemData.get("ward01");
		
		////	HashSet 객체 값들 다 찍기	////
		Set<String> keySet=itemData.keySet();	// 1.키 세트를 뽑아야함. Set 객체.
		Iterator<String> it=keySet.iterator();	// 2.위에서 뽑은 키 세트에서 이터레이터 객체 뽑기.
		while(it.hasNext()) {					// 3.이터레이터 it에 hasNext써서 값이 있는지 검사.
			String key=it.next();				// 4.이터레이터 it에 next써서 값하나 꺼내기(String 객체)
			Item item = itemData.get(key);		// 5.HashMap 객체의 get 함수의 매개변수에 4번에 
												// 꺼낸 키(String 객체)를 넣어 Item 객체꺼냄.
			System.out.println(key+":"+item.name);
		}
	}

}
