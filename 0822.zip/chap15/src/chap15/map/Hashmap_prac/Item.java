package chap15.map.Hashmap_prac;

public class Item {
	String name;
	int price;
	public Item(String name, int price) {
		this.name = name;
		this.price = price;
	}
}
