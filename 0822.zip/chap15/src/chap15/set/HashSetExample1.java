package chap15.set;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

public class HashSetExample1 {
	public static void main(String[] args) {
		Set<String> set = new HashSet<>();
		set.add("JAVA");
		set.add("JDBC");
		set.add("Servlet/JSP");
		set.add("Java");
		set.add("iBATIS");
//		set.add("JAVA"); <- 이건 있으나 마나임..
		
		System.out.println("총 개수 : "+set.size());
		Iterator<String> ite = set.iterator();
		
		while(ite.hasNext()) {
			System.out.println(ite.next());
		}
		System.out.println("===================================");
		set.remove("Java");
		System.out.println("총 개수 : "+set.size());
		
		Iterator<String> ite2 = set.iterator();
		while(ite2.hasNext()) {
			System.out.println(ite2.next());
		}
	}
}
