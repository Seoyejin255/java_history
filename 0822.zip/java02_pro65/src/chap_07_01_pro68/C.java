package chap_07_01_pro68;

public class C extends B{
	public int field2=55;
}
