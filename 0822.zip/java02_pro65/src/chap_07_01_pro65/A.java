package chap_07_01_pro65;

public class A {
	public int field1=55;
	
	void speak() {
		System.out.println("야호");
	}
}
