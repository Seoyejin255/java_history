package chap_07_01_pro65;

public class Main {

	public static void main(String[] args) {
		A a = new C();
		System.out.println(a.field1);
		a.speak();
		//System.out.println(c.field2); <-이건 오류남
	}

}
