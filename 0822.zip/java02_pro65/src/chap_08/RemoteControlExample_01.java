package chap_08;

public class RemoteControlExample_01 {

	public static void main(String[] args) {
		RemoteControl rc;
		rc = new Television();//구현 객체의 번지를 rc가 저장함
		rc = new Audio();//구현 객체의 번지를 rc가 저장함
	}

}
