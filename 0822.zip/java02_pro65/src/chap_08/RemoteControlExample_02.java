package chap_08;

public class RemoteControlExample_02 {

	public static void main(String[] args) {
		RemoteControl rc = new RemoteControl(){
			public void turnOn() {}
			public void turnOff() {}
			public void setVolume(int volume) {}
		};//그냥 생성한걸 익명으로 만든거임 {} 안에 코딩 다해야함
	}

}
