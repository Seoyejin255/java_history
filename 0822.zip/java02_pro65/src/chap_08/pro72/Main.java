package chap_08.pro72;

public class Main {

	public static void main(String[] args) {
		A a = new A() {
			@Override
			public void Speak() {
				System.out.println("이건 A의 익명함수 a입니다.");
			}
		};
		A b = new A() {

			@Override
			public void Speak() {
				System.out.println("이건 A의 익명함수 b입니다.");
			}
			
		};
		A c = new A() {

			@Override
			public void Speak() {
				System.out.println("이건 A의 익명함수 c입니다.");
			}
			
		};
		
		a.Speak();
		System.out.println(a.STR);
		b.Speak();
		System.out.println(b.STR);
		b.Speak();
		System.out.println(b.STR);
	}

}
