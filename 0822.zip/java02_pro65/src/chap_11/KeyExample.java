package chap_11;

import java.util.HashMap;

public class KeyExample {
	public static void main(String[] args) {
		HashMap<Key,String>hashMap=new HashMap<Key,String>();
		//Key 객체를 식별키로 사용하여 String 값을 저장하는 HashMap 생성
		hashMap.put(new Key(1), "홍길동");
		// new Key(1)로 홍길동을 ㅓ장
		String value = hashMap.get(new Key(1));
		//value 값에 홍길동을 불러옴.
		System.out.println(value);
		// 근데 null 값이 나옴 왜냐? number의 필드값이 같더라도 hashcode() 메소드에서 리턴해오는 해시코드가 다르기 때문.
		//객체 해시코드란? 객체를 구별할 하나의 정수값, 객체의 메모리 번지를 이용해서 해시코드를 만들기 때문에 객체마다 다른 값을 가져옴.
		//근데 key class에 hashcode메소드를 재정의 하자마자 나옴.,
	}
}
