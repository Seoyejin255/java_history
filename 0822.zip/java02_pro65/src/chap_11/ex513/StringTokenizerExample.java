package chap_11.ex513;

import java.util.StringTokenizer;

public class StringTokenizerExample {
	public static void main(String[] args) {
		String text="홍길동/이수홍/박연수";
		
		StringTokenizer st = new StringTokenizer(text,"/");//첫번째 매개값으로 문자열 전체를 주고 , 두번째 매개값으로 구분자를 주면됨.
		int countTokens = st.countTokens();//꺼내지 않고 남아있는 토근(문자열)의 수.
		
		for(int i=0;i<countTokens;i++) {//토큰의 개수 : 3개.
			String token =st.nextToken();//토큰을 하나씩 꺼내옴.
			System.out.println(token);
		}
		
		System.out.println();
		
		st=new StringTokenizer(text,"/");// 다시 첫번쨰 매개값으로 문자열을 주고 , 두번째로 구분자를 줌.
		while(st.hasMoreTokens()) {//토큰이 더 나아있다면.
			String token = st.nextToken();//토큰을 하나씩 읽어오고
			System.out.println(token);//토큰을 출력함. 즉 위에 있는 반복문이랑 똑같은 구조인거임.
		}
	}
}
