package chap_11;

public class MemberExample3 {
	public static void main(String[] args) {
		Member3 original = new Member3("홍길동",32,new int[]{90,100},new Car("람보르기니"));
		
		Member3 clonned = original.getMember();
		clonned.scores[0]=50;
		clonned.car.model="소나타";
		
		System.out.println("[복제 객체의 필드값]");
		System.out.println("name: " +clonned.name);
		System.out.println("age: " +clonned.age);
		System.out.print("scores: {");
		for(int i=0;i<clonned.scores.length;i++) {
			System.out.print(clonned.scores[i]);
			System.out.print((i==(clonned.scores.length-1))?"":",");
		}
		System.out.println("}");
		System.out.println("car: " +clonned.car.model);
		
		System.out.println("[원본 객체의 필드값]");
		System.out.println("name: " +original.name);
		System.out.println("age: " +original.age);
		System.out.print("scores: {");
		for(int i=0;i<original.scores.length;i++) {
			System.out.print(original.scores[i]);
			System.out.print((i==(original.scores.length-1))?"":",");
		}
		System.out.println("}");
		System.out.println("car: " +original.car.model);
		}
}
