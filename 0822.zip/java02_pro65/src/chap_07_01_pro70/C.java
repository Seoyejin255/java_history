package chap_07_01_pro70;

public class C extends A{

	@Override
	public void sound() {
		System.out.println("캐릭터소리");
	}


}
