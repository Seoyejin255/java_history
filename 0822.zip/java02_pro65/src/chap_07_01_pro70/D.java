package chap_07_01_pro70;

public class D extends B{

	@Override
	public void sound() {
		System.out.println("고양이소리");
	}


}
