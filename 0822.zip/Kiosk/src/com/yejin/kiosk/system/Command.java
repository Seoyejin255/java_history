package com.yejin.kiosk.system;

import java.util.Scanner;

public class Command {
	public static boolean button=true;
	
	public static String getCommand(String guide) {//입력받는 메소드
		Scanner sc = new Scanner(System.in);
		System.out.println(guide);
		String cmd = sc.next();
		return cmd;
	}
	
	public static boolean Turn_Off() {//마감할때
		String ON_OFF=Command.getCommand(Title.CLOSE);
		if(ON_OFF.equals("NO")||ON_OFF.equals("no"))button=true;
		else if(ON_OFF.equals("YES")||ON_OFF.equals("yes"))button=false;
		else {
			System.out.println("다시 입력해주세요");
			button=true;
		}
		return button;
	}
	
	public static boolean Turn_On() {//오픈할때
		String ON_OFF=Command.getCommand(Title.OPEN);
		if(ON_OFF.equals("YES")||ON_OFF.equals("yes"))button=true;
		else if(ON_OFF.equals("NO")||ON_OFF.equals("no"))button=false;
		else {
			System.out.println("다시 입력해주세요");
			button=false;
		}
		return button;
	}
	
	public static String table_select() {//테이블을 선택함
		System.out.println("1     2    3");
		System.out.println("4     5    6");
		System.out.println("7     8    9");
		String table_num=Command.getCommand("어떤 테이블을 선택하시겠습니까?");
		System.out.println("선택한 테이블 번호 : "+table_num);
		return table_num;
	}

	
}
