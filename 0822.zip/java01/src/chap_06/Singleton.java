package chap_06;

public class Singleton {

	int x=50;
	int y=40;
	int z;
	private static Singleton singleton = new Singleton();
	//정적(static)으로 선언해서 제일 먼저 만들어지게됨.
	private Singleton(){
	}
	
	static Singleton getInstance(){
		return singleton;
	}//이름을 getInstance라고 하는건 그냥 이동네 국룰임 ㅋ	
}
