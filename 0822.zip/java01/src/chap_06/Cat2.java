package chap_06;

public class Cat2 {
	String name;	
	int age;		
	String family;	
	String color;
	int hp = 100;
	int attack = 2;
	
	public Cat2(String name,int age,String family,String c) {
		this.name = name;
		this.age = age;
		this.family = family;
		this.color = c;
	}
	public Cat2(String n) {
		name = n;
	}
	public Cat2() {
		System.out.println("키티가 탄생!!");
	}

	void info() {
		String s =
				"이름:"+name+"\n"
				+"나이:"+age+"\n"
				+"품종:"+family+"\n"
				+"털색:"+color;
		System.out.println(s);
	}
	
	void move() {
		
	}
	
	void sleep() {
		
	}
	
	void eat() {
		
	}
	
}
