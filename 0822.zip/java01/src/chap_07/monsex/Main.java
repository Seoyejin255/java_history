package chap_07.monsex;

import java.util.ArrayList;

public class Main {
	public static void main(String[] args) {
		ArrayList<Monster> mons = new ArrayList<>();
		mons.add(new Elf());
		mons.add(new Orc());
		mons.add(new Elf());
		mons.add(new Elf());
		
		for(int i=0; i<mons.size();i++) {
			mons.get(i).x();
			mons.get(i).attack();
		}
	}
	
}
