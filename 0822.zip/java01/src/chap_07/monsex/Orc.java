package chap_07.monsex;

public class Orc extends Monster{

	@Override
	public void attack() {
		System.out.println("몽둥이 공격");
	}
	
}
