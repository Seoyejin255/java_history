package chap_07.pro54;

public abstract class Cat extends Animal{

	
}

/*
 public class Cat extends Animal{

	@Override
	public void sound() {
		System.out.println("애옹");
	}
	
}
 */
