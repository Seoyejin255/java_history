package pro_49;

public class Snake extends Animal{
	
	public Snake(String name) {
		super(name);
	}
	
	@Override
	void sound() {
		System.out.println("스스슥");
	}

	@Override
	void move() {
		System.out.println("뱀이 스르륵 기어갑니다.");
	}
	
}
