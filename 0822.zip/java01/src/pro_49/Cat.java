package pro_49;

public class Cat extends Animal{
	
	public Cat(String name) {
		super(name);
	}
	@Override
	void sound() {
		System.out.println("왜옹");
	}
}
