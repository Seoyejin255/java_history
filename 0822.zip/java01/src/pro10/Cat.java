package pro10;

public class Cat {
	public String name;
	public int age;
	public String family;
	public String color;
	
	public Cat(String name,int age,String family,String color) {
		this.name=name;
		this.age=age;
		this.family=family;
		this.color=color;
	}
	
	void info() {
		String str = String.format("고양이 이름 : %s\n고양이 나이 : %d\n고양이 타입 : %s\n고양이 색깔 : %s\n"
				,this.name,this.age,this.family,this.color);
		System.out.println(str);
	}
	
	void aging() {
		this.age++;
	}
}
