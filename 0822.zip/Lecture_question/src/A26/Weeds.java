package A26;

public class Weeds extends Plants{

}
