package chap13;

public class BoxExample {
	public static void main(String[] args) {
		Box<String> box1 = new Box<String>();
		box1.set("박스1");
		String str1 = box1.get();
		System.out.println(str1);
		
		Box<Integer> box2 = new Box<Integer>();
		box2.set(3);
		int str2=box2.get();
		System.out.println(str2);
	}
}
