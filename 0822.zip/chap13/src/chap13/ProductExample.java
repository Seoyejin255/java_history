package chap13;

public class ProductExample {
	public static void main(String[] args) {
		//너무 어려우면 그냥 tv,car로 바꿔서 읽어보면 됨.
		Product<Tv,String> product1 = new Product<Tv,String>();
		//product 클래스의 파라미터가<Tv,String> 인 product1 객체 생성.
		product1.setKind(new Tv());//새로 생성한 tv객체의 주소가 들어감
		product1.setModel("스마트Tv");//product1객체의 setModel 메소드를 통해 String "스마트tv"를 넘겨줌.
		Tv tv = product1.getKind();//tv객체의 주소를 리턴해줌.(Tv 클래스를 담을 수 있는 tv변수))
		String tvModel = product1.getModel();
		System.out.println(tv.a);
		System.out.println(tvModel);
		
		Product<Car,String> product2 = new Product<Car,String>();
		product2.setKind(new Car());
		product2.setModel("모닝");
		Car car = product2.getKind();
		String CarModel = product2.getModel();
		System.out.println(CarModel);
	}
}
