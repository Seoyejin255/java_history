package com.yejin.health_care.display;

public class Title {
	public static final String TITLE = "---------------------고양이 헬스장 관리 프로그램₍˄·͈ㅅ·͈˄₎◞-------------------\n";
	
	public static void showTitle() {
		System.out.println(TITLE);
	}
	
	public static void showExit() {
		System.out.println("-----------------------프로그램을 종료합니다------------------------");
	}
	public static void showError() {
		System.out.println("오타가 난거 같아요. 다시 입력해주세요.\n");
	}
	public static void showinfo() {
		System.out.println("-----------------------회원정보 출력------------------------");
	}
	public static void showdelete() {
		System.out.println("-----------------------회원정보 삭제------------------------");
	}
	public static void showEdit() {
		System.out.println("-----------------------회원정보 수정------------------------");
	}
	public static void noMember() {
		System.out.println("해당되는 회원이 없는데요?");
	}
}
