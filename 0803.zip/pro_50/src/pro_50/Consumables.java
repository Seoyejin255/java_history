package pro_50;

public class Consumables extends Item{

}
