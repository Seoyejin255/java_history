package pro_50;

public class Accessory extends Equipment{

}
