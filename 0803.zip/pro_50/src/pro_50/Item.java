package pro_50;

public class Item extends GameObject{

	public int maxDurability;
	public int currentDurability;
	public int price;
}
