package pro_50;

public class GameObject {
	public String id;
	public String name;
	
	public void info() {
		String str=String.format("아이디 : %s 이름 : %s", this.id,this.name);
		System.out.println(str);
	}
}
