package pro_50;

public class Player extends Character{

	public Player(String id, String name) {
		super(id, name);
	}

}
