package pro_50;

public class Arrmor extends Equipment{

}
