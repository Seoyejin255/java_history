package com.peisia.board2;

public class Comment{

	String nickname;
	String comment;
	int num;

	public Comment(String nickname, String comment, int num) {
		this.nickname = nickname;
		this.comment = comment;
		this.num = num;
	}
	
	
	
}
