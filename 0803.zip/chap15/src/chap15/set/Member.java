package chap15.set;

public class Member {
	public String name;
	public int age;

	public Member(String name, int age) {
		this.name = name;
		this.age = age;
	}
	
// 인스턴스가 달라도 이름과 나이가 동일하다면 동일한 객체로 간주하여 중복 저장되지 않도록.
	
	@Override
	public boolean equals(Object obj) {
		if(obj instanceof Member) {
			Member member = (Member)obj;
			return (member.age==this.age)&&(member.name.equals(this.name));
		}else {
			return false;
		}
	}
	
	@Override
	public int hashCode() {
		return name.hashCode()+age;
	
	}
}
