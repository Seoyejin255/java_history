package chap15.set;

import java.util.HashSet;
import java.util.Set;

public class HashSetExample2 {
	public static void main(String[] args) {
		Set<Member> set = new HashSet<>();
		set.add(new Member("가나다",10));
		set.add(new Member("가나다",10));
		
		System.out.println(set.size());
	}
}
