package chap15;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;

public class Q73_75 {
	public static void main(String[] args) {
		//ArrayList를 이용
		String LINE="=============================";
		List<String> list1 = new ArrayList<String>();
		list1.add("안녕1");
		list1.add("안녕2");
		list1.add("안녕3");
		list1.add("안녕4");
		System.out.println(list1.get(0));
		list1.set(0, "안녕1 수정");
		list1.remove(2);
		for(String str:list1) {
			System.out.println(str);
		}
		System.out.println(LINE);
		
		//---------------------------HashMap을 이용---------------------------
		HashMap<Integer,String> map1 = new HashMap<>();
		
		map1.put(0,"양고기");
		map1.put(1,"소고기");
		map1.put(2,"돼지고기");
		map1.put(3,"닭고기");
		map1.replace(1, "아 소고기 맛있겠따");
		map1.remove(0);
		
		for(int i=0;i<4;i++) {
			System.out.println(map1.get(i));
		}
		System.out.println(LINE);
		
		//-------------------------------HashSet을 이용----------------------------
		
		HashSet<String> home = new HashSet<>();
		home.add("집에");
		home.add("가고");
		home.add("싶어요");
		home.add("집에");
		
		Iterator<String> it = home.iterator();
		System.out.println(it.next());
		System.out.println(it.next());
		System.out.println(it.next());
		System.out.println(LINE);
		home.remove("싶어요");

		Iterator<String> it2 = home.iterator();
		System.out.println(it2.next());
		System.out.println(it2.next());
//		System.out.println(it2.next()); 오류남
	}
}
