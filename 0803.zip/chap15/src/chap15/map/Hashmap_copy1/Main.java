package chap15.map.Hashmap_copy1;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;

public class Main {
	public static void main(String[] args) {
		Map<String,Monster> mons = new HashMap<>();
		Map<String,User> user = new HashMap<>();
		
		mons.put("나방",new Monster("나브앙",30));
		mons.put("지렁이", new Monster("지르엉",50));
		mons.put("지네", new Monster("지이네",50));
		
		loop:
		while(true) {
			String select = Scan.getCommand("입력하세요 >> [1: 몬스터정보 , 2:유저 입력 , 3: 유저정보] ");
			switch(select) {
			
			case "1":
				Set<String> keySet = mons.keySet();
				Iterator<String> ite = keySet.iterator();
				while(ite.hasNext()) {
					String name = ite.next();
					mons.get(name).info();
				}
				System.out.println();
				break;
			case "2":
				String name=Scan.getCommand("유저의 이름");
				user.put(name, new User(name));
				break;
			case "3":
				Set<String> userSet = user.keySet();
				Iterator<String> userIte = userSet.iterator();
				while(userIte.hasNext()) {
					String userName = userIte.next();
					user.get(userName).User_info();
				}
			case "exit":
				System.out.println();
				break loop;
			}
			
		}
	}
}
