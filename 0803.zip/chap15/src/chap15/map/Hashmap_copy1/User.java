package chap15.map.Hashmap_copy1;

public class User {

	public String name;
	private int userAttack=10;

	public User(String name) {
		this.name = name;
	}
	
	public void User_info() {
		System.out.println("----------------[유저]------------------");
		System.out.println("이름 : " + this.name +"\t공격력 : "+this.userAttack);
	}
	
	
}
