package chap15.map.Hashmap_copy1;

public class Monster {

	public String name;
	public int atk;

	public Monster(String name, int atk) {
		this.name = name;
		this.atk = atk;
	}

	public void info() {
		System.out.println("----------------[몬스터]------------------");
		System.out.println("이름 : " + this.name +"\t공격력 : "+ this.atk);
	}
	
	
}
