package chap_09;

public class Outter {
	String field ="Outter-field";
	
	void method() {
		System.out.println("Outter-method");
	}
	
	class Nested{
		String field = "Nested-field";
		
		void method() {
			System.out.println("Nested method");
		}
		
		void print() {
			System.out.println(this.field);//nested-field출력
			this.method();//nested method 출력
			System.out.println(Outter.this.field);//outter-field 출력
			Outter.this.method();//outter-method 출력
		}
	}
}
