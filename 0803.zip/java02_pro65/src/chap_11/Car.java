package chap_11;

public class Car {
	public String model;

	public Car(String model) {
		this.model = model;
	}
	
	
}
