package chap_08;

public interface InterfaceB {
	public void methodB();
}
