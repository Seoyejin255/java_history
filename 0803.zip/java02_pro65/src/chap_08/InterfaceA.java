package chap_08;

public interface InterfaceA {
	public void methodA();
}
