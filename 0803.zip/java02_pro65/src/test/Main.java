package test;

public class Main {

	public static void main(String[] args) {
		B b = new B();
		A a = b;
		a.speak();
	}


}
