package chap_07_01_pro65;

public class C extends B{
	public int field2=50;

	@Override
	void speak() {
		System.out.println("이야호");
	}
	
}
