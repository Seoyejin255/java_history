package chap_07_01_pro68;

public abstract class A {
	public int field1=55;
}
