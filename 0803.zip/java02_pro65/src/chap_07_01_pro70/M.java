package chap_07_01_pro70;

public class M {

	public static void main(String[] args) {
		B b = new B();
		C c = new C();
		D d = new D();
		E e = new E();
		A a1 = b;//매개변수의 타입이 클래스일 경우 해당클래스의 객체뿐만 아니라 자식객체까지도 매개값으로 쓸수있음.
		A a2 = c;//강제 형변환의 형태는 아마도 A a1 = new B()일거임-> 이 형태에서 A는 B의 메소드 사용불가능?
		A a3 = d;
		A a4 = e;
		a1.sound();//따라서 B는 A(부모)를 상속받은 매개변수로 A는 B의 메소드도 사용이 가능하다?
		a2.sound();
		a3.sound();
		a4.sound();
	}

}
