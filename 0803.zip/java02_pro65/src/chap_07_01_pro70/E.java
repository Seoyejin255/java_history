package chap_07_01_pro70;

public class E extends C{

	@Override
	public void sound() {
		System.out.println("사람소리");
	}

	

}
