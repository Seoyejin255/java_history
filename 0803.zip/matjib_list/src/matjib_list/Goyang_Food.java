package matjib_list;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;

public class Goyang_Food extends Goyang{
	
	public Goyang_Food(String name) {
		super(name);
	}
	
	Map<String,Integer> hansik = new HashMap<>();
	Map<String,Integer> cafe = new HashMap<>();
	Map<String,Integer> wesFood  = new HashMap<>();
	List<String> randomF = new ArrayList<>();
	
	public void set_goyang() { // 입력한거 다 가져감.
		input_hansik();
		input_cafe();
		input_wesFood();
	}
	
	public void info(String str) {
		Map<String, Integer> map = null;
		switch(str) {
		case "한식":
			map = hansik;
			break;
		case "양식":
			map = wesFood;
			break;
		case "카페":
			map=cafe;
			break;
		}
		Set<String> set = map.keySet();
		Iterator<String> hanset = set.iterator();
		while(hanset.hasNext()) {
			String name = hanset.next();
			System.out.println("가게명 : "+ name + "\t가격" + map.get(name));
		}
	}
	//--------------------------------------------------------------------------------------------
	
	public void input_hansik() {//한식 정보를 넣음.
		hansik.put("고_한식1",1000);
		hansik.put("고_한식2",2000);
		hansik.put("고_한식3",3000);
		hansik.put("고_한식4",4000);
		hansik.put("고_한식5",5000);
	}
	
	public void input_cafe() {//카페 정보를 넣음.
		cafe.put("고_카페1",1000);
		cafe.put("고_카페2",2000);
		cafe.put("고_카페3",3000);
		cafe.put("고_카페4",4000);
		cafe.put("고_카페5",5000);
	}
	
	public void input_wesFood() {//서양음식을 넣음.
		wesFood.put("고_wesFood1",1000);
		wesFood.put("고_wesFood2",2000);
		wesFood.put("고_wesFood3",3000);
		wesFood.put("고_wesFood4",4000);
		wesFood.put("고_wesFood5",5000);
	}
	
	public void foodRandom() {
		double random = Math.random();
		int ranNum = (int)(random*14);
		Set<String> keys = hansik.keySet();
		Iterator<String> name = keys.iterator();
		while(name.hasNext()) {
			randomF.add(name.next());
		}
		Set<String> keys2 = cafe.keySet();
		Iterator<String> name2 = keys2.iterator();
		while(name2.hasNext()) {
			randomF.add(name2.next());
		}
		Set<String> keys3 = wesFood.keySet();
		Iterator<String> name3 = keys3.iterator();
		while(name3.hasNext()) {
			randomF.add(name3.next());
		}
		System.out.println("-------------<<    추천     >>-------------\n\t   "+randomF.get(ranNum)+"는 어떤가요?\n------------------------------------------");
	}
}
