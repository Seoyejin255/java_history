package matjib_list;

public class Goyang extends Area{

	public Goyang(String name) {
		this.name=name;
	}

}
