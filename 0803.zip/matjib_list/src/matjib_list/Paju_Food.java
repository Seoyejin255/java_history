package matjib_list;

public class Paju_Food extends Paju{

	public Paju_Food(String name) {
		super(name);
	}

}
