package matjib_list;

import java.util.Scanner;

public class  Command {

	public static String getCommand(String str){
		Scanner sc = new Scanner(System.in);
		System.out.println(str);
		String cmd = sc.next();
		return cmd;
	}
	
}
