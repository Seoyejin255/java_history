package A26;

public class Animal extends Life{
	public String moveType="";
	
	Animal(){
		System.out.println("부모 동물임");
	}
	Animal(String moveType){
		this.moveType=moveType;
	}
	
	public void move() {
		System.out.println(moveType);
	}
	
}
