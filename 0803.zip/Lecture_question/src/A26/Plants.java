package A26;

public class Plants {

}
