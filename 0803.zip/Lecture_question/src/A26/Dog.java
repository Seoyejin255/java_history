package A26;

public class Dog extends Animal{

}
