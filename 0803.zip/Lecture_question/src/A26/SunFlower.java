package A26;

public class SunFlower extends Plants{

}
