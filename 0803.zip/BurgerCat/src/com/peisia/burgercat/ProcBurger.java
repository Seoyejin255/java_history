package com.peisia.burgercat;

import java.util.ArrayList;

public class ProcBurger {
	public void run(ArrayList<String> basket) {

		loop:
		while(true) {
			//버거 메뉴 처리
			Command cmd = new Command(); 
			String c = cmd.getCommand("명령을 입력해주세요. [1:치즈와퍼,2:불고기와퍼,3:몬스터와퍼,c:취소,b:뒤로] :");
			
			switch(c) {
			case "1":
				System.out.println("치즈와퍼 선택함");
				basket.add("치즈와퍼");
				break;
			case "2":
				System.out.println("불고기와퍼 선택함");
				basket.add("불고기와퍼");
				break;
			case "3":
				System.out.println("몬스터와퍼 선택함");
				basket.add("몬스터와퍼");
				break;
			case "c":
				System.out.println("취소");
				break loop;
			case "b":
				System.out.println("뒤로");
				break loop;
			}
		}
	}
}
