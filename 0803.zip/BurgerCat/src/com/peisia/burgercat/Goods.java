package com.peisia.burgercat;

public class Goods {
	public int price;
	public String name;
}
