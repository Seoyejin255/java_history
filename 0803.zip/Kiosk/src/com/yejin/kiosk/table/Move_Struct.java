package com.yejin.kiosk.table;

public interface Move_Struct {
	public default void method2() {
		System.out.println("2");
	}
}
