package chap_02;

public class PromotionExample {
	public static void main(String[] args) {
		
		byte byteValue =10;
		int intValue = byteValue;
		System.out.println(intValue);
		
		char charValue='가';
		intValue = charValue; // char -> int로 타입변경(유니코드로 나옴)
		System.out.println("가의 유니코드 : " + intValue);
		
		intValue=500;
		long longValue = intValue; // int -> long으로 변경
		System.out.println(longValue);
		
		intValue=200;
		double doubleValue = intValue;// int -> doubleValue 로 변경.
		System.out.println(doubleValue);
	}
}
