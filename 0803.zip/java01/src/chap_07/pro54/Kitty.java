package chap_07.pro54;

public class Kitty extends Cat{

	@Override
	public void sound() {
		System.out.println("냥냥");
		
	}
	
}
