package chap_07;

public class ChildExample {
	public static void main(String[] args) {
		Parent parent = new Child();
		//자식인데 아빠인척, child는 힙메모리에 생성되어있고
		//parent를 담을 수 있는 parent 객체인거임(parent 클래스는 생성 x)
		parent.field1="data";
		parent.method1();
		parent.method2();
		
		Child child = (Child)parent;
		//강제형변환을 통해 child클래스의 메소드를 사용가능하도록 함.
		child.field2="yyy";
		child.method3();
	}
}
