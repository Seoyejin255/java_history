package chap_03;

public class StringEqualsExample {
	public static void main(String[] args) {
		String strVar1 = "신민철";
		String strVar2 = "신민철";// string은 문자열이 같을 경우 동일한 객체를 참조하게된다.
		
		if(strVar1 == strVar2) {
			System.out.println("strVar1과 strVar2의 참조가 같음");
		}else {
			System.out.println("strVar1과 strVar2의 참조가 다름");
		}
		
		if(strVar1.equals(strVar2)) {
			System.out.println("strVar1과 strVar2의 문자열이 같음");
		}
		
		String strVar3 = new String("신용철");
		String strVar4 = new String("신용철");//새로운 객체를 생성함으로, 서로 다른 객체를 참조하게 된다.
		
		if(strVar3 == strVar4) {
			System.out.println("strVar1과 strVar2의 참조가 같음");
		}else {
			System.out.println("strVar1과 strVar2의 참조가 다름");
		}
		
		if(strVar3.equals(strVar4)) {
			System.out.println("strVar1과 strVar2의 문자열이 같음");
		}
	}
}
