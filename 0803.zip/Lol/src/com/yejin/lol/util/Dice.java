package com.yejin.lol.util;

public class Dice {
	
	public static int random(int r) {
		int random=(int)(Math.random()*r+1);
		return random;
	}
}
