package com.peisia.board2;

public class User {
	String comment;
	String nickname;
	
}
