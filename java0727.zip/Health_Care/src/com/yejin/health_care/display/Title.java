package com.yejin.health_care.display;

public class Title {
public static final String TITLE = "고양이 헬스장 관리 프로그램";
}
