package com.yejin;

import com.yejin.health_care.member;
import com.yejin.health_care.display.Title;

public class main {
	
	public static void main(String[] args) {
		member mem1 = new member();
		member mem2 = new member();
		
		mem1.input_info();
		mem2.input_info();
		
		mem1.setName("김복순");
		mem1.setSex("여자");
		mem2.setTel("010-2322-1231");
		
		mem1.mem_info();
		mem2.mem_info();
		
		System.out.println(Title.TITLE);

	}
	
}
