package chap_07_01_pro67;

public class A {
	void sound() {
		System.out.println("소리");
	}
}
