package chap_07_01_pro67;

public class B extends A{

	@Override
	void sound() {
		System.out.println("동물소리");
	}

}
