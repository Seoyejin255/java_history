package chap_07_01_pro70;

public class B extends A{

	@Override
	public void sound() {
		System.out.println("동물소리");
	}


}
