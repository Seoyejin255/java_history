package chap_08;

public interface Tire {
	public void roll();
}
