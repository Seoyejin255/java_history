package chap_08.pro72;

public interface A {
	
	public String STR="이건 A인터페이스의 상수에요 ^^\n";
	
	public void Speak(); 
}
