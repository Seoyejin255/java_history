package chap_08;

public class Example {

	public static void main(String[] args) {
		ImplementationC imple = new ImplementationC();
		
		InterfaceA ia = imple;
		ia.methodA();
		System.out.println();
		//ia.methodB(); <- 오류
		//ia.methodC(); <- 오류
		
		InterfaceB ib = imple;
		ib.methodB();
		System.out.println();
		
		InterfaceC ic = imple;
		ic.methodA();
		ic.methodB();
		ic.methodC();
		System.out.println();
	}

}
