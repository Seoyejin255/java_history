package chap_08;

public class HanKookTire implements Tire{

	@Override
	public void roll() {
		System.out.println("한국타이어가 굴러갑니다.\n");
	}

}
