package chap_08;

public interface ChildInterface1 extends ParentInterface{
	public void method3();
}
