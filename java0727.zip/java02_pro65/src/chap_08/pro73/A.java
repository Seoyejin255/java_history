package chap_08.pro73;

public interface A {
	int VALUE1 = 1;
	void Speak_A();
}
