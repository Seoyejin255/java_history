package pro_50;

public class Mob extends Character{

	public Mob(String id, String name) {
		super(id, name);
	}

}
