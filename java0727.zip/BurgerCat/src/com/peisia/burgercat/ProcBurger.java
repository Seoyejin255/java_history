package com.peisia.burgercat;

import java.util.ArrayList;

import com.peisia.burgercat.data.Burger;
import com.peisia.burgercat.data.Goods;

public class ProcBurger {
	public void run(ArrayList<Goods> basket) {

		loop:
		while(true) {
			//버거 메뉴 처리
			Command cmd = new Command(); 
			String c = cmd.getCommand("명령을 입력해주세요. [1:치즈와퍼,2:불고기와퍼,3:몬스터와퍼,c:취소,b:뒤로] :");
			
			switch(c) {
			case "1":
				System.out.println("치즈와퍼 선택함");
				Burger b = new Burger();
				b.name = "치즈와퍼";
				b.price = 1000;
				b.expiryDate = "20220727";
				
				//int > long.
				int n = 10;
				long l;
				l = n;	// 형 변환(자동)
				
				n = (int)l;	//형 변환(강제, 수동)
				
				basket.add(b);	// 형 변환. type 변환. Burger >> Goods
				break;
				
			case "2":
				System.out.println("불고기와퍼 선택함");
				Burger b2 = new Burger();
				b2.name = "불고기와퍼";
				b2.price = 1500;
				b2.expiryDate = "20220727";
				basket.add(b2);
				break;
			case "3":
				System.out.println("몬스터와퍼 선택함");
				Burger b3 = new Burger();
				b3.name = "몬스터와퍼";
				b3.price = 2000;
				b3.expiryDate = "20220728";
				basket.add(b3);
				break;
			case "c":
				System.out.println("취소");
				break loop;
			case "b":
				System.out.println("뒤로");
				break loop;
			}
		}
	}
}
