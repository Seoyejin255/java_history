package com.peisia.burgercat;

import java.util.ArrayList;

public class ProcDrink {
	public void run(ArrayList<String> basket) {

		loop:
		while(true) {
			Command cmd = new Command(); 
			String c = cmd.getCommand("명령을 입력해주세요."
					+"[1:아메,2:핫초코,3:아이스초코,4:제로톡톡,"
					+"5:코카콜라,6:코카콜라제로,7:스프라이트,8:씨그램,9:미닛메이드오렌지,10:순수(미네랄워터)"
					+"c:취소,b:뒤로] :");
			
			switch(c) {
			case "1":
				System.out.println("아메 선택함");
				basket.add("아메");
				break;
			case "2":
				System.out.println("핫초코 선택함");
				basket.add("불고기와퍼");
				break;
			case "3":
				System.out.println("아이스초코 선택함");
				basket.add("아이스초코");
				break;
			case "4":
				System.out.println("제로톡톡 선택함");
				basket.add("제로톡톡");
				break;
			case "5":
				System.out.println("코카콜라 선택함");
				basket.add("코카콜라");
				break;
			case "6":
				System.out.println("코카콜라제로 선택함");
				basket.add("코카콜라제로");
				break;
			case "7":
				System.out.println("스프라이트 선택함");
				basket.add("스프라이트");
				break;
			case "8":
				System.out.println("씨그램 선택함");
				basket.add("씨그램");
				break;
			case "9":
				System.out.println("미닛메이드오렌지 선택함");
				basket.add("미닛메이드오렌지");
				break;
			case "10":
				System.out.println("순수(미네랄워터) 선택함");
				basket.add("순수(미네랄워터)");
				break;
			case "c":
				System.out.println("취소");
				break loop;
			case "b":
				System.out.println("뒤로");
				break loop;
			}
		}
	}
}
