package com.peisia.burgercat.data;

public class Side extends Food{

}
