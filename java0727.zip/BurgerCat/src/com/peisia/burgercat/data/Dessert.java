package com.peisia.burgercat.data;

public class Dessert extends Food{

}
