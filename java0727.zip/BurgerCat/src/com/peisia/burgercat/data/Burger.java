package com.peisia.burgercat.data;

public class Burger extends Food{
	public int n = 100;
	//주니어 , 와퍼, 스페셜..
}
