package com.peisia.burgercat.data;

public class PetFood extends Food{

}
