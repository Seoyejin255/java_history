package com.peisia.burgercat.data;

public class Goods {
	public int price;
	public String name;
}
