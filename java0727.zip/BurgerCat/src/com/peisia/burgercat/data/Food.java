package com.peisia.burgercat.data;

public class Food extends Goods{	
	public String expiryDate;
}
