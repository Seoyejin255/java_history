package com.peisia.burgercat.data;

public class Figure extends Goods{

}
