package com.peisia.burgercat.data;

public class Drink extends Food{
	//찬 뜨거운
}
