package pro_49;

public class Halk extends Animal{
	
	public Halk(String name) {
		super(name);
	}
	@Override
	void sound() {
		System.out.println("나는 헐크다!!!!!!!!!");
	}

	@Override
	void move() {
		System.out.println("헐크는 옷을 찢으며 달려갑니다.");
	}
	
}
