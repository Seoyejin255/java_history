package pro_49;

public class Animal {
	public String name;
	

	public Animal(String name) {
		this.name=name;
	}
	
	void sound() {
		System.out.println("흐흐");
	}

	void move() {
		System.out.println("어라 이 동물은 움직임이 없네요?");
		
	}
}
