package chap_06;

public class ClassExample_game {
	public static void main(String[] args) {
		//String name,int currentHp,int maxHp,int atk
		/* 1. 메소드를 공용으로 쓰고 싶으면 클래스를 따로 만들어서 해야하는지 -> ㅇㅇ 따로 자바 파일 만들어서 하면 됨.
		 * 2. elf1,elf2,elf3 같이 뒤에 반복되는 숫자를 for문으로 만들고싶으면 어떻게 해야할지. -> 배열을 사용하면 됨.
		 * 3.this..<- 이게 메소드를 가르키는지 클래스를 가르키는지 -> 생성자는 그저 필드를 초기화하는 역할이니까 클래스를 가르킴
		*/
		
		Character elf1 = new Character("엘프",100,100,10);
		Character elf2 = new Character("엘프2",90,102);
		Character elf3 = new Character("엘프3",70);
		Character elf4 = new Character("엘프4");
		
		
		Monster orc = new Monster("오크",300,300,3);
		Monster orc2 = new Monster("오크2",300,300);
		Monster orc3 = new Monster("오크3",300);
		Monster orc4 = new Monster("오크4");
		
		System.out.println("elf1의 이름 : " + elf1.name+"\nelf1의 현재 체력 : " + elf1.currentHp);
		System.out.println("elf1의 현재 체력 : " + elf1.maxHp + "\nelf1의 공격력 : " + elf1.atk+"\n");
		
		System.out.println("elf2의 이름 : " + elf2.name+"\nelf2의 현재 체력 : " + elf2.currentHp);
		System.out.println("elf2의 최대 체력 : " + elf2.maxHp + "\nelf2의 공격력 : " + elf2.atk+"\n");
		
		System.out.println("elf3의 이름 : " + elf3.name+"\nelf3의 현재 체력 : " + elf3.currentHp);
		System.out.println("elf3의 최대 체력 : " + elf3.maxHp + "\nelf3의 공격력 : " + elf3.atk+"\n");
		
		System.out.println("orc의 이름 : " + orc.name+"\norc의 현재 체력 : " + orc.currentHp);
		System.out.println("orc의 현재 체력 : " + orc.maxHp + "\norc의 공격력 : " + orc.atk+"\n");

		System.out.println("orc2의 이름 : " + orc2.name+"\norc2의 현재 체력 : " + orc2.currentHp);
		System.out.println("orc2의 현재 체력 : " + orc2.maxHp + "\norc2의 공격력 : " + orc2.atk+"\n");
		
		System.out.println("orc3의 이름 : " + orc3.name+"\norc3의 현재 체력 : " + orc3.currentHp);
		System.out.println("orc3의 현재 체력 : " + orc3.maxHp + "\norc3의 공격력 : " + orc3.atk+"\n");
		
		System.out.println("orc4의 이름 : " + orc4.name+"\norc4의 현재 체력 : " + orc4.currentHp);
		System.out.println("orc4의 현재 체력 : " + orc4.maxHp + "\norc4의 공격력 : " + orc4.atk+"\n");
		
		System.out.println("엘프1가 공격 받았습니다. -------------  엘프의 생명력 : " + elf1.Charac_attack(orc.atk));
		System.out.println("몬스터가 공격 받았습니다. ----------- 몬스터의 생명력 : "+ orc.Mons_attack(elf1.atk));
	}
}
