package chap_06;

public class CatExample {
	public static void main(String[] args) {
		
		Cat cat1 = Cat.getInstance();
		Cat cat2 = Cat.getInstance();
		
		System.out.println(System.identityHashCode(cat1));
		System.out.println(System.identityHashCode(cat2));
		System.out.println(cat1.hashCode());
		System.out.println(cat2.hashCode());
	}
}
