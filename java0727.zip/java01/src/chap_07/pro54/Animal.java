package chap_07.pro54;

public abstract class Animal {
	public abstract void sound();
}
