package chap_07.monsex;

public class Elf extends Monster{
	@Override
	public void attack() {
		System.out.println("활공격");
	}
	
}
