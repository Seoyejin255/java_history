package chap_07;

public class StudentExample {

	public static void main(String[] args) {
		Student student = new Student("홍길동","123456-1234567",1);
		//부모에게서 물려온 필드를 출력
		System.out.println("이름 : " + student.name);
		System.out.println("주민등록번호 : " + student.ssn);
		System.out.println("학생번호 : " + student.studentNo);
	}

}
