package com.yejin.lol.data.img;

public class Entrance {
	
	static final String ENTRANCE = " ************ \n " + " ..... ";
	
	public static void show() {
		System.out.println(ENTRANCE);
	}
}
