package matjib_list.loginpro;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import matjib_list.command.Command;

public class Manager{

	Map <String,User> manager = new HashMap<>();
	
	public void input_mem() {
		manager.put("manager", new User("1234","매니저1"));
	}
	
	public void newManager(String id,String pw, String nickname) {
		manager.put(id,new User(pw,nickname));
	}
	
	public List<String> loginPro(List<String> info) {

			boolean flag=true;
			while(flag) {
				String id=Command.getCommand("[관리자]아이디를 입력해주세요.");
				String pw=Command.getCommand("[관리자]비밀번호를 입력해주세요.");
				if(manager.get(id)!=null) {
					if(((manager.get(id)).pw).equals(pw)) {
						String nickname=(manager.get(id)).nickname;
						System.out.println("--------------------"+nickname+"님 안녕하세요 ^^--------------------");
						info.add(id);
						info.add(nickname);
						flag=false;
					}else {
						System.out.println("[관리자]로그인 실패");
						String str =Command.getCommand("다시 로그인 하시겠습니까 ? [yes/no]");
						if(str.equals("yes")){
						}else if(str.equals("no")) {
							flag=false;
						}
					}
				}else if(manager.get(id)==null) {
					System.out.println("아이디가 다릅니다. 다시입력해주세요.");
				}
			}
			
			return info;	
	}
//	public ArrayList<String> CusLogin( ArrayList<String> info) {
//		boolean flag=true;
//		while(flag) {
//			String id = Command.getCommand("아이디를 입력해주세요.");
//			String pw = Command.getCommand("비밀번호를 입력해주세요.");
//			if(customer.get(id)!=null) {
//				if((customer.get(id).pw).equals(pw)) {
//					String nickname=customer.get(id).nickname;
//					System.out.println("--------------------"+nickname+"님 안녕하세요 ^^--------------------");
//					info.add(id);
//					info.add(nickname);
//					flag =false;
//				}else if(((customer.get(id).pw).equals(pw))!=true){
//					String logFlag=Command.getCommand("비밀번호가 다릅니다. 다시 로그인 하시겠습니까 ? [yes/no]");
//					//여기에서 갑자기 terminal로 들어감 ㅠㅠ 수정해야됨..ㅠㅠㅠㅠㅠ
//					if(logFlag.equals("yes")) {
//					}else if(logFlag.equals("no")) {
//						flag=false;
//					}
//				}
//			}else {
//				System.out.println("id가 다릅니다. 다시 입력해주세요.");
//			}
//			}
//			return info;
//	}
	
	
}
