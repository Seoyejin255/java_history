package matjib_list.loginpro;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import matjib_list.board.Write;
import matjib_list.command.Command;

public class Customer{
	Map<String,User> customer = new HashMap<>();

	public void inputMem() {
		customer.put("mem1", new User("1234","멍청이"));
	}
	

	public ArrayList<String> CusLogin( ArrayList<String> info) {
		boolean flag=true;
		while(flag) {
			String id = Command.getCommand("아이디를 입력해주세요.");
			String pw = Command.getCommand("비밀번호를 입력해주세요.");
			if(customer.get(id)!=null) {
				if((customer.get(id).pw).equals(pw)) {
					String nickname=customer.get(id).nickname;
					System.out.println("--------------------"+nickname+"님 안녕하세요 ^^--------------------");
					info.add(id);
					info.add(nickname);
					flag =false;
				}else if(((customer.get(id).pw).equals(pw))!=true){
					String logFlag=Command.getCommand("비밀번호가 다릅니다. 다시 로그인 하시겠습니까 ? [yes/no]");
					//여기에서 갑자기 terminal로 들어감 ㅠㅠ 수정해야됨..ㅠㅠㅠㅠㅠ
					if(logFlag.equals("yes")) {
					}else if(logFlag.equals("no")) {
						flag=false;
					}
				}
			}else {
				System.out.println("id가 다릅니다. 다시 입력해주세요.");
			}
			}
			return info;
	}
	public static void dbRun() {
		try {
			Connection con = null;
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/kiosk", "root", "admin");
			java.sql.Statement st = null;	// Statement는 정적 SQL문을 실행하고 결과를 반환받기 위한 객체다. Statement하나당 한개의 ResultSet 객체만을 열 수있다.
			ResultSet result = null;
			st = con.createStatement();
			result = st.executeQuery("select * from cat_board ");
			while (result.next()) {	// 결과를 하나씩 빼기. 더 이상 없으면(행 수가 끝나면) false 리턴됨.
				String name = result.getString("id");	// p_name 필드(열) 의 데이터 꺼내기(1개 꺼낸거에서)
				System.out.println(name);
			}
		} catch (SQLException e) {
			System.out.println("SQLException: " + e.getMessage());
			System.out.println("SQLState: " + e.getSQLState());
		}
		
	}
	
}
