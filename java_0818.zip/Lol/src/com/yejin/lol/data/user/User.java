package com.yejin.lol.data.user;

import com.yejin.lol.util.Dice;

public class User {
	static public String name="";
	static public String job="";
	static public String sex="";
	static public int currentHp=100;
	static public int maxHp=300;
	static public int atk=30;
	
	public void user_info() {
		String s = String.format("[이름 : %s]\n직업 : %s\n성별 : %s\n체력 : %d/%d\n공격력 : %d\n", name,job,sex,currentHp,maxHp,atk);
		System.out.println(s);
	}
	
	public int attack(String name, int hp) {
		String name2=name;
		this.atk=Dice.random(this.atk);
		this.currentHp-=hp;
		String s = String.format("%s는 %s에게 %d의 데미지를 입혔습니다.",this.name,name2,this.atk);
		System.out.println(s);
		return this.atk;
	}
}