package com.yejin.lol.data.string;

public class Str {
	static public final String CMD_GUIDE_CHARACTER_NAME_INPUT = "캐릭터 이름을 입력해주세요.";
	static public final String CMD_GUIDE_CHARACTER_JOB_INPUT = "캐릭터 직업을 입력해주세요.";
	static public final String CMD_GUIDE_CHARACTER_SEX_INPUT = "캐릭터 성(여자/남자)을 입력해주세요.";
	
}
