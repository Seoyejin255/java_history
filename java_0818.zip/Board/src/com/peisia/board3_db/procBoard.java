package com.peisia.board3_db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class procBoard {
	Connection con = null;
	Statement st = null;
	ResultSet result = null;
	void db_update(String id,String title,String content) {//글 추가
		dbInit();
//		dbExecuteQuery("select * from tottenham_squad where p_number=7");
		dbExecuteUpdate("insert into board (btitle,bid,bdate,bcontent) values ('"+title+"','"+id+"',now(),'"+content+"');");
	}
	
	void db_list() {//글리스트
		dbInit();
		dbExecuteQuery("select * from board where btitle is not null;");
	}
	void show_writing(String num) {
		dbInit();
		dbExecuteQuery2("select * from board where bNum='"+num+"';");
		dbExecuteQuery3("select * from board where comNum='"+num+"';");
	}
	
	void db_delete(String num) {//글삭제
		dbExecuteUpdate("delete from board where bNum ='"+num+"';");
	}
	
	void db_edit(String type,String edit,String num) {//글 수정
		dbInit();
		if(type.equals("제목")) {
			dbExecuteUpdate("update board set btitle='"+edit+"' where bNum ='"+num+"';");	
		}else if(type.equals("내용")) {
			dbExecuteUpdate("update board set bcontent='"+edit+"' where bNum ='"+num+"';");
		}
	}
	
	void db_like(String num) {//공감 +1 
		dbExecuteUpdate("update board set bLike=bLike+1 where bNum ='"+num+"';");
	}
	void db_popular() {
		dbInit();
		dbExecuteQuery("select * from board where bLike>=5;");
	}
	void db_comment(String num, String nickname,String comment) {
		dbExecuteUpdate("insert into board (comNum,bid,bdate,com) values ('"+num+"','"+nickname+"',now(),'"+comment+"');");
	}
	
	private void dbInit() {//최초에 한번만 하면되는 부분임..
		try {
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/kiosk", "root", "admin");
			st = con.createStatement();	// Statement는 정적 SQL문을 실행하고 결과를 반환받기 위한 객체다. Statement하나당 한개의 ResultSet 객체만을 열 수있다.
		} catch (SQLException e) {
			System.out.println("SQLException: " + e.getMessage());
			System.out.println("SQLState: " + e.getSQLState());
		}
	}
	
	private void dbExecuteQuery(String query) {
		try {
			result = st.executeQuery(query);//sql문을 실제로 db에 전송하는거.
			while (result.next()) {	// 결과를 하나씩 빼기. 더 이상 없으면(행 수가 끝나면) false 리턴됨.
				String number = result.getString("bNum");
				String id = result.getString("bid");
				String title = result.getString("btitle");
				String content = result.getString("bcontent");
				String date = result.getString("bdate");
				String like = result.getString("bLike");// p_name 필드(열) 의 데이터 꺼내기(1개 꺼낸거에서)
				String str = String.format("[%s] %s | %s | %s (%s) ", number,id,title,date,like);
				System.out.println(str);
			}
		} catch (SQLException e) {
			System.out.println("SQLException: " + e.getMessage());
			System.out.println("SQLState: " + e.getSQLState());
		}
	}	
	private void dbExecuteQuery2(String query) {
		try {
			result = st.executeQuery(query);//sql문을 실제로 db에 전송하는거.
			while (result.next()) {	// 결과를 하나씩 빼기. 더 이상 없으면(행 수가 끝나면) false 리턴됨.
				String number = result.getString("bNum");
				String id = result.getString("bid");
				String title = result.getString("btitle");
				String content = result.getString("bcontent");
				String date = result.getString("bdate");
				String like = result.getString("bLike");// p_name 필드(열) 의 데이터 꺼내기(1개 꺼낸거에서)
				String str = String.format("[%s] 닉네임 | %s\n제목 | %s\n내용 | %s\n시간 | %s",number,id,title,content,date);
				System.out.println(str);
				//클래스를 만들어서 글 하나가 하나의 객체가 되게 만들면 편함
			}
		} catch (SQLException e) {
			System.out.println("SQLException: " + e.getMessage());
			System.out.println("SQLState: " + e.getSQLState());
		}
	}
	private void dbExecuteQuery3(String query) {
		try {
			result = st.executeQuery(query);//sql문을 실제로 db에 전송하는거.
			System.out.println("\n----------------------------------\n");
			while (result.next()) {	// 결과를 하나씩 빼기. 더 이상 없으면(행 수가 끝나면) false 리턴됨.
				String id = result.getString("bid");
				String content = result.getString("com");
				String date = result.getString("bdate");
				String str = String.format("[%s]\n%s\t %s\n",id,content,date);
				System.out.println(str);
				//클래스를 만들어서 글 하나가 하나의 객체가 되게 만들면 편함
			}
		} catch (SQLException e) {
			System.out.println("SQLException: " + e.getMessage());
			System.out.println("SQLState: " + e.getSQLState());
		}
	}
	
	private void dbExecuteUpdate(String query) {
		try {
//			int resultCount = st.executeUpdate(query);
			st.executeUpdate(query);
//			System.out.println("처리된 행 수:"+resultCount);
		} catch (SQLException e) {
			System.out.println("SQLException: " + e.getMessage());
			System.out.println("SQLState: " + e.getSQLState());
		}
	}	
}
