package com.peisia.board3_db;


public class Post{
	String title;//글제목
	String id;//아이디
	int no;//글번호
	String content;//글제목
	String now;//시간
	int like;//공감
	int count=0;//댓글카운트
}
