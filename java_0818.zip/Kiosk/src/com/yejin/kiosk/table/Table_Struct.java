package com.yejin.kiosk.table;

public interface Table_Struct extends Move_Struct,Order_Struct{  

}
