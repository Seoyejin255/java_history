package DBs;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class DB {
	Connection conn = null;
	Statement st = null;
	ResultSet rs = null;
	
	
	public void dbInit() throws SQLException{
		conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/plantgame","root","admin");
		st = conn.createStatement();
	}
	
	public String dbExecuteQuery(String query,String want) throws SQLException {
		rs = st.executeQuery(query);
		String a=null;
		while(rs.next()) {
			String nickname = rs.getString("unickname");
			String info = rs.getString("uinfo");
			String flower = rs.getString("uflower");
			String collection = rs.getString("collection");
			String ufGrow = rs.getString("ufGrow");
			if(want.equals("닉네임")) {
				a=nickname;
			}else if(want.equals("꽃")) {
				a=flower;
			}else if(want.equals("콜렉션")) {
				a=collection;
			}else if(want.equals("성장")) {
				a=ufGrow;
			}
		}
			return a;
	}
	public String fExecuteQuery(String query,String want) throws SQLException {
		rs = st.executeQuery(query);
		String a=null;
		
		while(rs.next()) {
			String num = rs.getString("num");
			String name = rs.getString("fname");
			String info = rs.getString("feature");
			int growPoint = rs.getInt("growPoint");
			String image = rs.getString("image");
			if(want.equals("꽃")) {
				a=name;
			}else if(want.equals("유저꽃")) {
				System.out.println("["+name+"]");
				System.out.println(image);
				System.out.println("▶ 꽃특징 : "+info);
				System.out.println("▶ 요구하는 성장포인트 : "+growPoint+"\n");
			}else if(want.equals("이미지")) {
				System.out.println(image);
			}
		}
			return a;
	}
	public ArrayList<Integer> fAExecuteQuery(String query) throws SQLException {
		rs = st.executeQuery(query);
		ArrayList<Integer> level = new ArrayList<>();
		while(rs.next()) {
			level.add(rs.getInt("sprout"));//새싹
			level.add(rs.getInt("stem"));//줄기
			level.add(rs.getInt("growPoint"));//완성형
		}	
			return level;
	}
	public void dbExecuteUpdate(String query) throws SQLException {
		st.executeUpdate(query);
	}
	
	public int fCount(String query) throws SQLException {//꽃의 컬럼 개수를 세는 함수.
		rs =st.executeQuery(query);
		int rowcount =0;
		while(rs.next()) {
			rowcount++;
		}
		return rowcount;
	}
}
