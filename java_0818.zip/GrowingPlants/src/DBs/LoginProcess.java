package DBs;

import java.sql.SQLException;

import System.Command;

public class LoginProcess {
	DB db = new DB();
	Command cm = new Command();
	
	public String userLog() throws SQLException {
		db.dbInit();
		String id= cm.getCommand("▶ 아이디를 입력해주세요.");
		String pw = cm.getCommand("▶ 비밀번호를 입력해주세요.");
		String Unickname=db.dbExecuteQuery("select * from user where uid ='"+id+"' and upw ='"+pw+"'","닉네임");
		if(Unickname==null) {
			System.out.println("▶ 로그인 실패했습니다.");
		}else {
			System.out.println("▶ 로그인 성공했습니다.");
		}
		return Unickname;
	}
}
