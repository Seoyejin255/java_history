package System;

import java.util.Scanner;

public class Command {
	public static String TITLE="ꕤꕥ ꕤꕥ ꕤꕥ 꽃 키우기 ꕤꕥ ꕤꕥ ꕤꕥ";
	public static String TWOLINE="====================================================";
	public static String MYSTERY="\r\n"
			+ "⠀⢀⣤⣤⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣶⣶⣦⠀⠀\r\n"
			+ "⠀⠘⢫⣯⠇⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣤⡀⠀⠈⣭⣜⡻⠀⠀\r\n"
			+ "⠀⠀⠘⣧⢀⠤⠢⢄⡤⠤⢒⣶⣶⣴⣿⣿⣿⣧⠀⣻⡋⠀⠀⠀\r\n"
			+ "⠀⠀⠀⠉⢸⠀⠀⠠⠀⠀⠘⢿⣿⣿⣿⣿⣿⡇⠀⠙⠁⠀⠀⠀\r\n"
			+ "⠀⠀⠀⠀⠀⡝⠀⠀⠀⠀⠀⠀⢉⢭⣍⠉⠉⢱⡀⠀⢿⣿⣷⠀\r\n"
			+ "⠀⠀⠀⠀⠀⡇⠠⣿⣷⠀⠀⠀⠘⠛⢛⣀⠀⠀⡇⠀⡿⠛⠁⠀\r\n"
			+ "⠀⠀⠀⠀⢰⠁⣤⡬⠀⠀⠀⠆⠀⠀⠈⠁⠀⠀⡇⠈⠛⠀⠀⠀\r\n"
			+ "⠀⠀⠀⠀⠸⡀⠀⠀⣀⠔⡆⠀⠀⠀⠀⠀⠀⢰⠃⠀⠀⠀⠀⠀\r\n"
			+ "⠀⠀⠀⠀⠀⠘⡖⠊⠀⡘⠁⠀⠀⠀⠀⠀⠀⠈⢣⠀⠀⠀⠀⠀\r\n"
			+ "⠀⠀⠀⠀⠀⠘⢄⣀⡰⠃⠀⠀⠀⠀⠀⠀⠀⢀⠀⡇⠀⠀⠀⠀\r\n"
			+ "⠀⠀⠀⠀⠀⠀⢰⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠸⣤⠃⠀⠀⠀⠀\r\n"
			+ "";
	public static String SEED ="어떤 씨앗일까요?";
	public static String SPROUT = "새싹이 돋았어요!!!";
	public static String STEM ="줄기가 자랐어요 ! 어떤 꽃이 될까요?";
	public static String FEATURE="강아지풀이에요!";
	public static String getCommand(String str){
		Scanner sc = new Scanner(System.in);
		System.out.println(str);
		String cmd = sc.next();
		return cmd;
	}
	public static void MysteryInfo() {
		System.out.println("[ 발견하지 못한 꽃 ]");
		System.out.println(MYSTERY);
		System.out.print("▶ 꽃 특징 : ? \n");
		System.out.println("▶ 요구하는 성장포인트 : ? \n");
	}
	

	
	
}
