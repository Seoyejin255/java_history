package Objects;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import DBs.DB;
import System.Command;

public class Flower {
	static DB db = new DB();
	static Command command = new Command();
	public static String findFlower(String user) throws SQLException {//user의 꽃을 보는 함수([1]기능)
		db.dbInit();
		String flower=db.dbExecuteQuery("select * from user where unickname='"+user+"'", "꽃");
		if(flower==null) {
			String str =Command.getCommand("▶ 꽃을 배정받지 않았습니다. 새로 만들까요?-----[yes / no]");
			if(str.equals("yes")) {
				getFlower(user);
			}else {
				System.out.println("▶ 꽃을 배정받지 않았습니다.");
			}
		}else if(flower!=null) {
			ufGrow(user,flower);
		}
		return flower;
	}
	
	public static void getFlower(String user) throws SQLException {//user의 꽃이 배정되지 않았을때 꽃을 랜덤으로 배정해주는 함수.
		//select count(*) from flower;
		db.dbInit();
		int num=db.fCount("select * from flower");
		int rannum=(int) (Math.random()*num+1);
		String flower =db.fExecuteQuery("select * from flower where num='"+rannum+"'", "꽃");
		db.dbExecuteUpdate("update user set uflower='"+flower+"' where unickname='"+user+"'");
	}
	
	public static void flowerImage(String flower) throws SQLException {//유저 꽃의 완성형 이미지를 보여주는 함수.
		db.dbInit();
		db.fExecuteQuery("select * from flower where fname='"+flower+"'", "유저꽃");
	}
	
	public static void ufGrow(String user,String flower) throws SQLException {//grow에 따라 다른 이미지를 내보내는 함수.
		db.dbInit();
		ArrayList<Integer> level;
		int grow=Integer.parseInt(db.dbExecuteQuery("select * from user where unickname='"+user+"'", "성장"));//ufGrow를 가져옴.
		level=db.fAExecuteQuery("select * from flower where fname='"+flower+"'");
		if(level.get(0)>grow) {
			System.out.println(command.SEED);
			db.fExecuteQuery("select * from flower where fname='씨앗'","이미지");
		}else if(level.get(1)>grow) {
			System.out.println(command.SPROUT);
			db.fExecuteQuery("select * from flower where fname='새싹'", "이미지");
		}else if(level.get(2)>grow) {
			System.out.println(command.STEM);
			db.fExecuteQuery("select * from flower where fname='줄기'", "이미지");
		}else if(level.get(2)<=grow){
			System.out.println(command.FEATURE);
			db.fExecuteQuery("select * from flower where fname='"+flower+"';", "이미지");
			//여기서 db를 날리고 컬렉션에 더해버리자.
			String inputCo=Command.getCommand("▶ 꽃을 도감에 넣으시겠습니까? ------ [yes/no]");
			if(inputCo.equals("yes")) {
			}
		}
	}
	public static void dropAdd() {// 컬렉션에 더하고 지우는 함수
		
	}
	
}
