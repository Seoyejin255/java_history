package Main;

import java.sql.SQLException;

import Objects.Collection;
import Objects.Flower;
import System.Command;

public class Game {
	
	public boolean play(String user) throws SQLException {
		Flower flower = new Flower();
		Collection collection = new Collection();
		
		boolean flag=true;
		System.out.println(Command.TWOLINE);
		String a=Command.getCommand("✿❀ ▷[1] 나의 꽃 [2] 꽃 돌보기 [3] 꽃 도감 [0] 게임 종료◁ ❀✿");
		System.out.println(Command.TWOLINE);
		String fName;//유저의 꽃 이름.
		switch(a) {
		case "1":
			fName=flower.findFlower(user);
			break;
		case "2":
//			꽃을 돌보는 곳. 난이도 조절, 물주는 기능
			break;
		case "3" :
//			꽃도감 칸 1)전체 꽃 보기-> 두개씩 넘기면서 보기(미완) & 꽃 검색하기. 2)나의 컬렉션 기능 추가 예정.
			String c=Command.getCommand("✿❀ ▷[1] 전체 꽃 보기 [2] 나의 컬렉션들  [0] 그만보기◁ ❀✿");
			if(c.equals("1")) {
				collection.CollPaging(user);
			}else if(c.equals("2")) {//나의 컬렉션 보기.
				collection.UserCollection(user);
			}else if(c.equals("0")) {
				
			}
			break;
		case "0":
			flag=false;
			break;
		}
		return flag;
	}
}
