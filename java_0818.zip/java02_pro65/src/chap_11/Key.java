package chap_11;

import java.util.Objects;

public class Key {
	public int number;

	public Key(int number) {
		this.number = number;
	}
	
	@Override
	public boolean equals(Object obj) {//object 형식의 객체가 들어옴.(클래스)
		if(obj instanceof Key) {//obj가 Key객체로 만들어진게 맞는가
			Key compareKey = (Key) obj;//맞으면  Key를 담을수 있는 compareKey 객체에 obj를 key 형식으로 강제형변환함.
			if(this.number==compareKey.number) {// 이 클랙스의 변수 number와 넘어온 객체의 number가 같으면
				return true;//true리턴
			}
		}
		return false;//false 리턴
	}//-> 즉 필드값을 비교하는 함수로 재정의 한거임.

	
	@Override
	public int hashCode() {
		return number;
	}
	
}
