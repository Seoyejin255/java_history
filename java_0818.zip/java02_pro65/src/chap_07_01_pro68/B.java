package chap_07_01_pro68;

public class B extends A{

}
