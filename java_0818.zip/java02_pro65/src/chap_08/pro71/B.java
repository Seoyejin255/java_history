package chap_08.pro71;

public class B implements A{

	@Override
	public void Speak() {
		System.out.println("오우 여긴 A인터페이스의 구현객체 B입니다~ 추상 메소드를 재정의했어요 ^^");
	}

}
