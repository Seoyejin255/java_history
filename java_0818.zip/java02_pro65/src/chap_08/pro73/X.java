package chap_08.pro73;

public class X implements A,B{

	@Override
	public void Speak_A() {
		System.out.println("A 추상메소드입니다.");
	}

	@Override
	public void Speak_B() {
		System.out.println("B 추상메소드입니다.");
	}
	
}
