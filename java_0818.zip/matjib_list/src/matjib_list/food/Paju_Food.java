package matjib_list.food;

import matjib_list.parentclass.Paju;

public class Paju_Food extends Paju{

	public Paju_Food(String name) {
		super(name);
	}

}
