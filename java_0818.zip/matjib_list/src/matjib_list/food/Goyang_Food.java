package matjib_list.food;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;

import matjib_list.command.Command;
import matjib_list.parentclass.Goyang;

public class Goyang_Food extends Goyang{
	
	public Goyang_Food(String name) {
		super(name);
	}
	
	Map<String,Food> hansik = new HashMap<>();
	Map<String,Food> cafe = new HashMap<>();
	Map<String,Food> wesFood  = new HashMap<>();
	Map<String,Food> selectMap;
	List<String> randomF = new ArrayList<>();
	

	public void get_goyang() { // 입력한거 다 가져감.
		input_hansik();
		input_cafe();
		input_wesFood();
	}
	
	public void info(String str) { // 음식 정보를 출력하는 메소드 + 자세히
		selectMap(str);
		Set<String> set = selectMap.keySet();
		Iterator<String> hanset = set.iterator();
		while(hanset.hasNext()) {
			String name = hanset.next();
			System.out.println("가게명 : "+ name);
		}
		String lookD=Command.getCommand(">>>>>>>>>>>>> 자세히 보기(입력 : 자세히) <<<<<<<<<<<<<<");
		if(lookD.equals("자세히")) {
			String shopName=Command.getCommand("가게 이름을 입력해주세요.");
			Command.drawLine();
			System.out.println("[가게 이름]  " + shopName + "\n[가게 정보]  " + selectMap.get(shopName).food_info + "\n[가게위치]   " + selectMap.get(shopName).food_location + "\n[가격대]     "+selectMap.get(shopName).food_value);
			Command.drawLine();
		}
	}
	public void selectMap(String str) {//Map을 선택하는 함수.
		switch(str) {
		case "한식":
			selectMap = hansik;
			break;
		case "양식":
			selectMap = wesFood;
			break;
		case "카페":
			selectMap=cafe;
			break;
		}
	}
	public void editFood(String map,String name) {//name은 수정할 가게 이름, //map은 수정할 음식점의 종류
		selectMap(map);
		String fEdit=Command.getCommand("수정할 음식의 정보는?[정보,가격,위치]");
		String fWord=Command.getCommand("["+fEdit+"]내용을 입력하세요.");
		selectMap.get(name).food_eidt(fEdit, fWord);
	}
	
	public void foodRandom() {//랜덤으로 가게를 추천하는 함수.
		double random = Math.random();
		int ranNum = (int)(random*(randomF.size()));
		System.out.println("\n    제작자 :  < 오늘의 식당을 추천해줄게요 ^^)");
		System.out.println("-------------<<    추천     >>-------------\n\t   "+randomF.get(ranNum)+"은(는) 어떤가요?\n------------------------------------------");
	}
	
	public void foodAdd() {
		String fType=Command.getCommand("어떤 종류의 음식점을 수정하시겠습니까?[한식/카페/양식]");
		selectMap(fType);
		String name=Command.getCommand("가게 이름을 입력하세요");
		String info=Command.getCommand("가게 정보를 입력하세요.");
		String value=Command.getCommand("평균 가격대를 입력하세요.");
		String location= Command.getCommand("가게 위치를 입력하세요.");
		
		selectMap.put(name, new Food(info,Integer.parseInt(value),location));
		randomF.add(name);
	}
	
	//----------------------------------------------배열에 정보 넣는 줄-------------------------------------------------------
	
	
	public void input_hansik() {//한식 정보를 넣음.
		hansik.put("한그릇뚝딱",new Food("집밥, 찌개류",9000,"학원 주변 어딘가에 있음.."));
		hansik.put("오빠네옛날떡볶이",new Food("분식",5000,"학원 주변 어딘가에 있음.."));
		hansik.put("봉평막국수",new Food("막국수",9000,"학원 주변 어딘가에 있음.."));
		hansik.put("모랑해물솥밥",new Food("솥밥류",9500,"웨돔쪽에 있음"));
		hansik.put("큰맘할매순대국",new Food("순댓국",7000,"학원 주변 어딘가에 있음.."));
		hansik.put("다온",new Food("닭칼국수,닭개장 등.. ",7500,"학원 주변 어딘가에 있음.."));
		hansik.put("최고당돈까스",new Food("돈까스",9500,"학원 주변 어딘가에 있음.."));
		hansik.put("카츠온반",new Food("돈까스",13000,"학원 주변 어딘가에 있음.."));
		Set<String> keys = hansik.keySet();
		Iterator<String> name = keys.iterator();
		while(name.hasNext()) {
			randomF.add(name.next());
		}
	}
	
	public void input_cafe() {//카페 정보를 넣음.
		cafe.put("빽다방",new Food("저렴하고 기본적인 카페",4000,"학원 주변 어딘가에 있음.."));
		cafe.put("올댓커피",new Food("카페정보2",6500,"학원 주변 어딘가에 있음.."));
		cafe.put("마법과자점",new Food("카페정보2 ",3000,"학원 주변 어딘가에 있음.."));
		cafe.put("우주라이크",new Food("카페정보2 ",4500,"학원 주변 어딘가에 있음.."));
		cafe.put("메가커피",new Food("카페정보2 ",4000,"학원 주변 어딘가에 있음.."));
		Set<String> keys2 = cafe.keySet();
		Iterator<String> name2 = keys2.iterator();
		while(name2.hasNext()) {
			randomF.add(name2.next());
		}
	}
	
	public void input_wesFood() {//서양음식을 넣음.
		wesFood.put("포케",new Food("양식정보1",10500,"학원 주변 어딘가에 있음.."));
		wesFood.put("맥도날드",new Food("양식정보2",5000,"학원 주변 어딘가에 있음.."));
		wesFood.put("최고당돈까스",new Food("양식정보3",9500,"학원 주변 어딘가에 있음.."));
		wesFood.put("노브랜드",new Food("양식정보4",4000,"학원 주변 어딘가에 있음.."));
		wesFood.put("버거킹",new Food("양식정보5",6000,"학원 주변 어딘가에 있음.."));
		Set<String> keys3 = wesFood.keySet();
		Iterator<String> name3 = keys3.iterator();
		while(name3.hasNext()) {
			randomF.add(name3.next());
		}
	}
	
	
}
