package matjib_list.parentclass;

public class Area {
	public String name;
	public String type;
	
	
}
