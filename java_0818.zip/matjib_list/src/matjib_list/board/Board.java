package matjib_list.board;

import java.util.ArrayList;
import java.util.List;

import matjib_list.command.Command;
import matjib_list.loginpro.Customer;

public class Board extends Customer{

	public String content;
	public String title;
	List<Write> writings = new ArrayList<>();
	
	public void create() {
		String login=Command.getCommand("[회원]로그인 하시겠습니까?----yes/no");
		if(login.equals("yes")) {
			CusLogin();
			if(status.equals("true")) {
				String title=Command.getCommand("<<제목 입력>>");
				String content = Command.getCommand("<<내용 입력>>");
				writings.add(new Write(nowNick,nowCus,title,content));
				//닉네임,id,title,content
			}
		}else if(login.equals("no")) {
			System.out.println("비회원은 작성할 수 없습니다.");
		}
		
	}
	
//	public void showBoard() {
//		Command.drawLine();
//		System.out.println(title + "\t\t|" + +"|");
//		Command.drawLine();
//		System.out.println(content);
//	} 미완성
	
	public void showList() {
		Command.drawTwoLine();
		Command.drawTwoLine();
		if(writings.size()<0) {
			System.out.println("글이 없습니다.");
		}else {
			for(int i=0;i<writings.size();i++) {
				String str = String.format("[%s]%s | %s ",nowCus,writings.get(i).nickname,writings.get(i).title);
				System.out.println(str);
				Command.drawLine();
			
			}	
		}
		
		Command.drawTwoLine();
	}
	

}

