package matjib_list.command;

import java.util.Scanner;

public class  Command {

	public static void drawLine() {
		System.out.println("---------------------------------------");
	}
	public static void drawTwoLine() {
		System.out.println("=======================================");
	}
	public static String getCommand(String str){
		Scanner sc = new Scanner(System.in);
		System.out.println(str);
		String cmd = sc.next();
		return cmd;
	}
	
}
