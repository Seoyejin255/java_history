package chap15;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
	
	public class A73_75 {
	

		public static void main(String[] args) {
			//A073
//			List	ArrayList	객체를 만들고	변수 저장은 List 에 저장		List<String> l = new ArrayList<>();			
//			crud(입력, 값읽기, 값바꾸기, 값삭제) 하기	
//			add	get	set	remove			
			List<String> animals = new ArrayList<>();
			animals.add("고양이");
			animals.add("개");
			System.out.println(animals.get(0));
			animals.set(0, "개냥이");	//0 인덱스 값 바꾸기
			System.out.println(animals.get(0));
			animals.remove(0);
			System.out.println(animals.get(0));
			
			System.out.println("================================");
			//A074
//			Map	HashMap	객체를 만들고	crud(입력, 값읽기, 값바꾸기, 값삭제)					
//			put	get	replace	remove
			HashMap<Integer,String> burgers = new HashMap<>();
			burgers.put(100,"치즈와퍼");
			burgers.put(200,"불고기와퍼");
			System.out.println(burgers.get(100));
			System.out.println(burgers.get(200));
			burgers.replace(100, "몬스터와퍼");	//100 인덱스(?) 값 바꾸기
			System.out.println(burgers.get(100));
			burgers.remove(100);
			System.out.println(burgers.get(100));
			
			
			System.out.println("================================");
//			A075
//			Set						
//			HashSet	객체를 만들고						
//			crd(입력, 값읽기, 값삭제 ) 하기
//			add	 remove
			HashSet<String> ani = new HashSet<>();
			ani.add("너굴맨");
			ani.add("사자");
			ani.add("토끼");
			ani.add("토끼");
			Iterator<String> it=ani.iterator();	// Set종류들은 이거 써서 값 꺼내야함.
			System.out.println(it.next());	//참고: 순서대로 안나옴. Set종류들은 순서가 없음 얘는.
			System.out.println(it.next());
			System.out.println(it.next());
//			System.out.println(it.next()); 에러남. 3개라서. 토끼 두번추가 안됨.
			ani.remove("토끼");
			Iterator<String> it22=ani.iterator();
			System.out.println(it22.next());
			System.out.println(it22.next());
//			System.out.println(it22.next()); 에러남. 2개라서.		

	}

}
