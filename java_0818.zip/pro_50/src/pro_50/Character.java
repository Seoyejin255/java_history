package pro_50;

public class Character extends GameObject{
	
	public Character(String id, String name) {
		this.id=id;
		this.name=name;
	}
	public int maxHp;
	public int currentHp;
}
