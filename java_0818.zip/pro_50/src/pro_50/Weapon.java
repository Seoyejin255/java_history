package pro_50;

public class Weapon extends Equipment{

}
