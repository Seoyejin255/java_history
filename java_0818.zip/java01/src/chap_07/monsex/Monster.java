package chap_07.monsex;

public class Monster {
	public void x() {
		System.out.println("x실행");
	}
	public void attack() {
		System.out.println("몬스터가 공격합니다.");
	}
}
