package chap_07;

public class Student extends People{

	public int studentNo;
	
	public Student(String name,String ssn,int studentNo) {
		super(name,ssn);// 부모 클래스의 생성자 호출함
		this.studentNo=studentNo;
	}
	
}
