package chap_07;

public class Calculator {
	double areaCircle(double r) {
		System.out.println("Calculator 클래스의 areaCircle() 실행");
		return 3.14159*r*r;
	}
}
