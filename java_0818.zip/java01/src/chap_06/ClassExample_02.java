package chap_06;

public class ClassExample_02 {
	public static void main(String[] args) {
		
		Character[] elf = new Character[4];
		Monster[] orc = new Monster[4];
		
		elf[0] = new Character("엘프",100,100,10);
		elf[1] = new Character("엘프2",90,102);
		elf[2] = new Character("엘프3",70);
		elf[3] = new Character("엘프4");
		
		
		orc[0] = new Monster("오크",300,300,3);
		orc[1] = new Monster("오크2",300,300);
		orc[2] = new Monster("오크3",300);
		orc[3] = new Monster("오크4");
		
		for(int i=0;i<elf.length;i++) {
			System.out.println("elf" + i + "의 이름 : " + elf[i].name+"\nelf" + i + "의 현재 체력 : " + elf[i].currentHp);
			System.out.println("elf" + i + "의 현재 체력 : " + elf[i].maxHp + "\nelf" + i + "의 공격력 : " + elf[i].atk+"\n");
		}
		
		for(int i =0;i<orc.length;i++) {
			System.out.println("orc" + i +"의 이름 : " + orc[i].name+"\norc" + i +"의 현재 체력 : " + orc[i].currentHp);
			System.out.println("orc" + i +"의 현재 체력 : " + orc[i].maxHp + "\norc" + i +"의 공격력 : " + orc[i].atk+"\n");
		}
		
		System.out.println("엘프1가 공격 받았습니다. -------------  엘프의 생명력 : " + elf[0].Charac_attack(orc[0].atk));
		System.out.println("몬스터1가 공격 받았습니다. ----------- 몬스터의 생명력 : "+ orc[0].Mons_attack(elf[0].atk));
		
		System.out.println(Character.CAT);
	}
}
