package test;

public class B extends A{
	
	@Override
	void speak() {
		System.out.println("방가방가 햄토리 ~");
	}
	
}
