package test;

public class A {
	
	void speak() {
		System.out.println("안녕??");
	}
}
