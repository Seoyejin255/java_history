package chap_08;

public interface Searchable {
	void search(String url);
}
