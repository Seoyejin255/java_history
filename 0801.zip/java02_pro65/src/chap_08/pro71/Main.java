package chap_08.pro71;

public class Main {

	public static void main(String[] args) {
		A a;// 인터페이스 변수 a 선언
		a = new B();//B의 번지를 담고있는 a변수
		a.Speak();//B의 Speak()함수
		System.out.println(a.STR);//A인터페이스의 상수 출력
	}
}
