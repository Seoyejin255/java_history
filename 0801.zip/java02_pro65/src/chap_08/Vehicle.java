package chap_08;

public interface Vehicle {
	public void run();
}
