package chap_08.pro73;

public interface B {
	int VALUE=3;
	void Speak_B();
}
