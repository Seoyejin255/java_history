package chap_07_01_pro67;

public class E extends C{
	@Override
	void sound() {
		System.out.println("사람소리");
	}
}
