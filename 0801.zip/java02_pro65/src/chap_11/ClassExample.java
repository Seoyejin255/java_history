package chap_11;

public class ClassExample {
	public static void main(String[] args) {
		Car car = new Car("그랜저");
		Class clazz1= car.getClass();
		System.out.println("clazz1.getName() : "+clazz1.getName());//chap_11.Car <- 
		System.out.println("clazz1.getSimpleName()) : "+clazz1.getSimpleName());
		System.out.println("clazz1.getPackage().getName() : "+clazz1.getPackage().getName());
		System.out.println();
		
		try {
			Class clazz2 = Class.forName("chap_11.Car");
			System.out.println("clazz2.getName() : "+clazz2.getName());
			System.out.println("clazz2.getSimpleName()) : "+clazz2.getSimpleName());
			System.out.println("clazz2.getPackage().getName() : "+clazz2.getPackage().getName());
		}catch(ClassNotFoundException e) {
			e.printStackTrace();
		}
		
		
	}
}
