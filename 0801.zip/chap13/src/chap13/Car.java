package chap13;

public class Car {
	public String a="부릉이";
}
