package chap13;

public class Tv {
	public String a ="어쩔티비";
}
