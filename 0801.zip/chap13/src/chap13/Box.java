package chap13;

public class Box<T> {
	private T t; // T타입의 t변수.
	
	public T get() { //T타입의 get 메소드
		return t; // t를 리턴함.
	}
	
	public void set(T t) {
		this.t=t;
	}
}
