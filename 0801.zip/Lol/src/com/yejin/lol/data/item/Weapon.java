package com.yejin.lol.data.item;

public class Weapon {

}
