package com.yejin.lol.data.control;

import com.yejin.lol.data.monster.Goblin;
import com.yejin.lol.data.monster.Orc;
import com.yejin.lol.data.string.Str;
import com.yejin.lol.data.user.User;

public class Game {
//
	User user=new User();
	Command cmd= new Command();
	public final String game_over="게임이 종료됩니다.";
	Orc[] orc= new Orc[2];
	Goblin[] goblin= new Goblin[3];
	
	
	public void start() {
		
		//오크 2마리 고블린 3마리 생성
		orc[0] = new Orc("오크1",100,100,10);
		orc[1] = new Orc("오크2",200,200,20);
		goblin[0]=new Goblin("고블린1",200,100,10);
		goblin[1]=new Goblin("고블린2",200,200,20);
		goblin[2]=new Goblin("고블린3",200,300,30);
		
		
		for(int i=0;i<orc.length;i++) {
			orc[i].orc_info();
		}
		for(int i=0;i<goblin.length;i++) {
			goblin[i].goblin_info();
		}
		gameRun();
	}

	private void gameRun() {
		boolean str=true;
		String s;
		while(str) {
			User.name =cmd.getCommand(Str.CMD_GUIDE_CHARACTER_NAME_INPUT);//유저클래스의 이름변수를 입력받음
			User.job =cmd.getCommand(Str.CMD_GUIDE_CHARACTER_JOB_INPUT);//유저클래스의 직업변수를 입력받음
			User.sex =cmd.getCommand(Str.CMD_GUIDE_CHARACTER_SEX_INPUT);//유저클래스의 성변수 입력받음
			s = cmd.getCommand("나가고싶으면 exit를 입력해주세요.");
			if(s.equals("exit")) {//exit랑 같으면 true
				str=false;
			}
		}
		//유저클래스의 유저인포함수(유저의 정보) 호출
		user.user_info();
		gameOver();
	}
	
	private void gameOver() {
		System.out.println(game_over);
	}
	
	public void procBattle(){
		goblin[0].attack();
		int value=(int) user.attack(goblin[0].name,goblin[0].currentHp);
		goblin[0].currentHp=goblin[0].currentHp-value;
		user.user_info();
		goblin[0].goblin_info();
	}
}
