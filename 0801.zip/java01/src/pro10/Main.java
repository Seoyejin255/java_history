package pro10;

public class Main {
	public static void main(String[] args) {
		Cat kitty = new Cat("냥냥이",2,"샴고양이","회색");
		Cat yaongi = new Cat("야옹이",4,"길고양이","노란");
		
		kitty.info();
		yaongi.info();
		
		kitty.aging();
		yaongi.aging();
		
		kitty.info();
		yaongi.info();
	}
}
