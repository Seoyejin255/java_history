package chap_06;


public class Dog {
	int name;
	int age;
	int hp = 50;
	int attack = 1;
	
	void eat() {
		
	}
	
	void attack() {
		
	}
}
