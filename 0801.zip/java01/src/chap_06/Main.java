package chap_06;

public class Main {
		public static void main(String[] args) {
			
			Cat2 kitty = new Cat2();
			Cat2 yaongi = new Cat2("야옹이",2,"잡종","까망");
			Cat2 x = new Cat2("x고양이");
			
			Dog mung = new Dog();
			
			
			kitty.hp = kitty.hp - mung.attack; 
			
			
			int r = (int)(Math.random() * 6 + 1);
			
			kitty.age = r;
			kitty.name = "키티";
			kitty.family = "페르시아고양이";
			kitty.color = "흰색";

			kitty.info();
	}

}
