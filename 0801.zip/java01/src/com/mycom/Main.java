package com.mycom;
public class Main {
	public static void main(String[] args) {
		com.google.Game game_g = new com.google.Game();
		com.peisia.Game game_p = new com.peisia.Game();
		
		game_g.info();
		game_p.info();
	}
}
