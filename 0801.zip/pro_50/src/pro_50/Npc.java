package pro_50;

public class Npc extends Character{

	public Npc(String id, String name) {
		super(id, name);
	}

}
