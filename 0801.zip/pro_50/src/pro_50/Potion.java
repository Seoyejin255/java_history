package pro_50;

public class Potion extends Consumables{

}
