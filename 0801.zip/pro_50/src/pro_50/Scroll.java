package pro_50;

public class Scroll extends Consumables{

}
